/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw10_131044022_ilaydazeynep_ozdemir;

import static hw10_131044022_ilaydazeynep_ozdemir.Operand.share;

/**
 *Abstract
 * Interfaceden implement edildi
 * @author ilayda zeynep ozdemir
 */
abstract class Expression extends MyException implements InterfaceOfExpression {

    /**
     *
     */
    private String m_expression;

    /*
     *No-Parameter Constructor
     *
     */
    public Expression() {
        setExpr("");

    }

    /*
     *No-Parameter Constructor
     *
     */
    public Expression(String taken) {
        setExpr(taken);
    }

    /**
     *
     * @param exp(string)
     */
    public void setExpr(String exp) {
        m_expression = exp;
    }

    /**
     *
     * @return
     */
    @Override
    public String getExpr() {
        return m_expression;
    }

    /**
     *
     * @param i
     * @return
     */
    public Expression getKeep(int i) {
        return (Expression) keep.get(i);
    }

    /**
     *keep'e ekler
     * @param exp(Expression)
     */
    public void addKeep(Expression exp) {//adini add keep yap
        keep.add(exp);
    }

    /**
     *
     * @return
     */
    @Override
    public String toString() {
        String res = "";
       //System.out.printf("%d\n", keep.size());
        for (int i = 0; i < Expression.keep.size(); ++i) {
            res = res + keep.get(i).getExpr();
        }

        return res;
    }

    /**
     * @param expr
     * @return
     */
    public boolean equals(Expression expr) {
        return expr.equals(m_expression);
    }

    /**
     *
     * @return
     */
    @Override
    public int evaluates() {
        int i = 0;
        int keep_i;
        //System.out.printf("keepsize =  %d \n", Expression.keep.size());
        share();//static operand fonksiyonu
        //share ile alt sinifa bagli oldu
        //kotu bir sey cozum bulmayi unutma!!
        while (i < Expression.keep.size()) {
            keep_i = i;
            //System.out.printf("index1= %d \n", i);
            i = Expression.keep.get(i).doThing(i);
            //System.out.printf("index2 = %d \n", i);
            if (keep_i == i) {
                ++i;
            }

        }
        return 0;
    }

    /**
     *abstract method
     * @param index
     * @return
     */
    @Override
    abstract public int doThing(int index);

}
