/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw10_131044022_ilaydazeynep_ozdemir;

import static hw10_131044022_ilaydazeynep_ozdemir.Operand.keepOperand;

/**
 * Abstract
 *Expressiondan turetildi
 * @author ilayda process fonksiyonu yazilamiyor
 */
abstract class Operator extends Expression {

    private int orderOfPredecence;
    private int resultOfProcess;

    Operand leftOperand;//her operatorun operandi vardir
    Operand rightOperand;//her operatorun operandi vardir

    /**
     * Constructor
     *
     */
    public Operator() {
        super();
        leftOperand = new Operand();
        rightOperand = new Operand();

    }

    /**
     * Constructor
     *
     * @param taken
     */
    public Operator(String taken) {
        super(taken);
        leftOperand = new Operand();
        rightOperand = new Operand();

    }

    /**
     *
     * @param left
     */
    public void setLeftOperand(Operand left) {
        this.leftOperand = left;
    }

    /**
     *
     * @param rigth
     */
    public void setRightOperand(Operand right) {
        this.rightOperand = right;
    }

    /**
     *
     * @return leftOperand
     */
    public Operand getLeftOperand() {
        return leftOperand;
    }

    /**
     *
     * @return rightOperand
     */
    public Operand getRightOperand() {
        return rightOperand;
    }

    /**
     *
     * @return
     */
    public int getResultOfProcess() {
        return resultOfProcess;
    }

    /**
     *
     * @param result
     */
    public void setResultOfProcess(int result) {
        // System.out.printf("RESULT =//////%d\n", result);
        this.resultOfProcess = result;
    }

    /**
     *
     * @param orderOfPre
     */
    public void setOrderOfPredecence(int orderOfPre) {
        this.orderOfPredecence = orderOfPre;
    }

    /**
     *
     * @return
     */
    public int getOrderOfPredecence() {
        return orderOfPredecence;
    }

    /**
     * abstract method,islemleri yonlendirir
     *
     * @return int
     */
    abstract public Operand process();

    /**
     * 
     * @param index
     * @return
     */
    @Override
    public int doThing(int index) {
        //System.out.printf("%d\n", index);

        if (index != Expression.keep.size() - 1) {
            setLeftOperand(keepOperand.firstElement());
            //System.out.printf("%d\n", index);
            keepOperand.remove(keepOperand.firstElement());
            setRightOperand(keepOperand.firstElement());
            keepOperand.remove(keepOperand.firstElement());
        } else if (index == Expression.keep.size() - 1) {
            setLeftOperand(keepOperand.firstElement());
        }
        keepOperand.add(0, this.process());//basa ekler
        return index;
    }

    private void find_High_OrderOfProcess() {

    }

}
