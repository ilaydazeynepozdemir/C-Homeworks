/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw10_131044022_ilaydazeynep_ozdemir;

/**
 *Exceptiondan turetildi
 * @author ilayda zeynep ozdemir
 */
public class MyException extends Exception {

    String m_wrong;

    public MyException() {
    }

    public MyException(String wrong) {
        m_wrong=wrong;

    }

}
