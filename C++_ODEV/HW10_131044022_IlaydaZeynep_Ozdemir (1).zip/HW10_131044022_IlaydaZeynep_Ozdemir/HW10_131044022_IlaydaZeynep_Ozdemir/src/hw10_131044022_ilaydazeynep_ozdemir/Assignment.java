/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw10_131044022_ilaydazeynep_ozdemir;

import java.util.Vector;

/**
 *Operatorden turetildi
 * @author ilayda zeynep ozdemir
 */
public class Assignment extends Operator {

    /**
     * Constructor
     *
     */
    public Assignment() {
        super();
    }

    /**
     * Constructor
     *
     * @param taken
     */
    public Assignment(String taken) {
        super(taken);
        // setExpr(taken);

    }

    /**
     *
     * @return
     */
    @Override
    public Operand process() {//islemin son hali donecek
        //super.process(index);
        //System.out.printf("-----%d\n", leftOperand.getValueOfOperand());
        setResultOfProcess(leftOperand.getValueOfOperand());
        return new Operand(Integer.toString(getResultOfProcess()));
    }

}
