/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package hw10_131044022_ilaydazeynep_ozdemir;

/**
 *
 * @author ilayda
 */
/*public class IntOperand extends Operand{

    public IntOperand() {
        super();
    }

    IntOperand(String taken) {
        super(taken);
    }

    
    @Override
    public int orderOfPredecence(String taken) {
        return 0;
    }
    
}*/
