/*
 * öncelik yok
 */
package hw10_131044022_ilaydazeynep_ozdemir;

//import java.util.ArrayList;
import java.util.Vector;

/**
 *Operatorden turetildi
 * @author ilayda
 */
public class Plus extends Operator {
/**
     * Constructor
     *
     */
    Plus() {
        super();
        // this.setExpr("");

    }

    /**
     * Constructor
     *
     * @param taken
     */
    Plus(String taken) {
        super(taken);
        // this.setExpr(taken);

    }

    /**
     * 
     * @return
     */
    @Override
    //left right bos doldur !!!
    public Operand process() {
        setOrderOfPredecence(1);
        setResultOfProcess(leftOperand.getValueOfOperand() + rightOperand.getValueOfOperand());
        return new Operand(Integer.toString(getResultOfProcess()));
    }

}
