package hw10_131044022_ilaydazeynep_ozdemir;

import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.Vector;

//Odev oncelik sirasina gore islem yapmiyor 
//Yollanma sirasina gore islem yapiyor
//Dogru sekilde girildiginde islemler yapiliyor

/**
 *Test
 * @author ilayda zeynep ozdemir
 */
public class HW10_131044022_IlaydaZeynep_Ozdemir {

    /**
     * @param args 
     */
    public static void main(String[] args) {

        test();

    }

    /**
     *test fonksiyonu
     * kullanicidan verileri alarak keep'i set eder
     */
    public static void test() {

        Scanner input = new Scanner(System.in);
        System.out.println("Enter your expression, after each operator or operand press enter, to end the expression press =\n");
        String take;
        Assignment opr;
        opr = new Assignment();
        boolean sign = true;
        try {
            do {
                System.out.println("Enter your expression element\n");
                take = input.next();
                sign = true;
                switch (take) {

                    case "+":
                        opr.addKeep(new Plus(take));
                        break;
                    case "-":
                        opr.addKeep(new Minus(take));
                        break;
                    case "*":
                        opr.addKeep(new Multiplication(take));
                        break;
                    case "/":
                        opr.addKeep(new Divide(take));
                        break;
                    case "=":
                        opr.addKeep(new Assignment(take));
                        break;
                    case "(":
                    case ")":
                        opr.addKeep(new Paranthesis(take));
                        break;
                    default:
                        if (take.contains("+") || take.contains("-")) {//contains varsa true doner
                            sign = false;
                            System.out.println("Wrong!! Try again! \n");
                        } else if (take.contains("*") || take.contains("/")) {
                            sign = false;
                            System.out.println("Wrong!! Try again! \n");
                        } else if (take.contains("(") || take.contains(")")) {
                            sign = false;
                            System.out.println("Wrong!! Try again! \n");
                        } else if (take.contains("=")) {
                            sign = false;
                            System.out.println("Wrong!! Try again! \n");
                        } else {
                            opr.addKeep(new Operand(take));
                            break;
                        }
                }
            } while (!take.equals("=") || sign != true);

            opr.evaluates();

        } catch (NoSuchElementException ex ) {
        //hatayi cozup yolla!
        } 

        System.out.printf("Girdi : %s\n", opr.toString());
        System.out.printf("Cikti : %s\n",Operand.keepOperand.get(0));

    }

}
