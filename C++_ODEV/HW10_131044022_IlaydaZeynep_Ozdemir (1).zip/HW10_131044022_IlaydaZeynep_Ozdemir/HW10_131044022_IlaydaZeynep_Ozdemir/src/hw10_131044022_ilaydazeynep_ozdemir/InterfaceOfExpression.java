/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw10_131044022_ilaydazeynep_ozdemir;

import java.util.Vector;

/**
 * Interface
 *
 * @author ilayda zeynep ozdemir
 *
 */
public interface InterfaceOfExpression {

    Vector<InterfaceOfExpression> keep = new Vector<>();

    
    /**
     *
     * ifadeleri anlamlandirir
     * @return
     */
    public int evaluates();

    /**
     *yardimci fonksiyon,evalutes tarafindan cagirilir
     * @param index
     * @return
     */
    int doThing(int index);

    /**
     *
     * Expressionu verir(string)
     * @return
     */
    public String getExpr();
}
