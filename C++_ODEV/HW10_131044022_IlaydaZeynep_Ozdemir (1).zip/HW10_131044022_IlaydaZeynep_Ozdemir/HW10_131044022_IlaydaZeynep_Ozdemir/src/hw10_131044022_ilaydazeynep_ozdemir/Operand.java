/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw10_131044022_ilaydazeynep_ozdemir;

import java.util.Vector;

/**
 *Expressiondan turetildi
 * @author ilayda
 */
//Operand da Operator gibi abstract olsun 
//bundan intOperand turet
class Operand extends Expression {

    static Vector<Operand> keepOperand = new Vector<>();
    private int valueOfOperand;

    /**
     * Constructor
     *
     */
    Operand() {
        super();
        setValueOfOperand(0);
    }

    /**
     * Constructor
     *
     * @param taken
     */
    Operand(String taken) {
        super(taken);
        setValueOfOperand(taken);
    }
    
    @Override
    public String toString(){
        return Integer.toString(getValueOfOperand());
    }

    /**
     * @param valueOfOpr
     *
     */
    public void setValueOfOperand(String valueOfOpr) {
        this.valueOfOperand = Integer.parseInt(valueOfOpr);
    }

    /**
     * @param valueOfOpr
     *
     */
    public void setValueOfOperand(int valueOfOpr) {
        this.valueOfOperand = valueOfOpr;
    }

    /**
     *
     * @return
     */
    public int getValueOfOperand() {
        return valueOfOperand;
    }

    /**
     * @param index
     * @return
     */
    @Override
    public int doThing(int index) {
        //System.out.printf("operandda  = %s\n", keep.get(index).getExpr());
        
        return index + 1;
    }

    static public int share() {
        int a=0;
        for (int i = 0; i < Expression.keep.size(); ++i) {
            if (Expression.keep.get(i) instanceof Operand) {
                keepOperand.add((Operand) keep.get(i));
               // System.out.printf("## %s\n", keepOperand.get(a));
                ++a;
            }
        }

        return 0;
    }

}
