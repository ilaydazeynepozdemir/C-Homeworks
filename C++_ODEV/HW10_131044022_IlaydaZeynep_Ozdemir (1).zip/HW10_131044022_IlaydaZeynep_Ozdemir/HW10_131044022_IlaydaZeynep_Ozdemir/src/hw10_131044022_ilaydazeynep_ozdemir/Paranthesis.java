/*
 *Parantezler islevsel degil
*öncelik yok
 */
package hw10_131044022_ilaydazeynep_ozdemir;

import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *Operatorden turetildi
 * @author ilayda
 */
public class Paranthesis extends Operator {

    /**
     * Constructor
     *
     */
    Paranthesis() {
        // super();

    }

    /**
     * Constructor
     *
     * @param taken
     */
    Paranthesis(String taken) {
        //super(taken);
    }

    /**
     *
     * @return @throws hw10_131044022_ilaydazeynep_ozdemir.MyException
     */
    @Override
    public Operand process() {
        try {
            throw new MyException("Not supported yet.");
        } catch (MyException ex) {
            Logger.getLogger(Paranthesis.class.getName()).log(Level.SEVERE, null, ex);//!! duzeltilmedi
        }
        return null;
    }

    /*public int InsideParanthesisProcess(){
        
     }*/
}
