/* 
 * File:   Numbers.cpp
 * Author: ilayda zeynep ozdemir
 * 
 * Created on December 14, 2015, 12:07 AM
 */

#include "Numbers.h"
#include <iostream>
#include <cstdlib>
namespace NUMBERS__ {

    Numbers::Numbers() : m_number(0) {

    }

    Numbers::Numbers(double num) {
        set(num);
    }

    void Numbers::set(const double num) {
        m_number = num;
    }

    std::ostream& operator<<(std::ostream& out, const Numbers& number) {
        out << "Numbers sinifinin insertion operatoru cagirilmamali" << std::endl;
        exit(1);
    }

    bool Numbers::operator<(const Numbers& right)const {
        if (get() < right.get())
            return true;
        else return false;
    }

    Numbers& Numbers::operator=(const Numbers& rValue) {
        this->set(rValue.get());
        return (*this);
    }

}
