/* 
 * File:   Complex.cpp
 * Author: ilayda zeynep ozdemir
 * 
 * Created on December 14, 2015, 12:09 AM
 */

#include "Complex.h"
#include "math.h"
namespace NUMBERS__ {

    Complex::Complex() : Numbers(0) {
        setImaginary(0);
        setReal(0);
    }

    Complex::Complex(double real) : Numbers(real) {
        setImaginary(0);
        setReal(real);
    }

    Complex::Complex(double real, double imaginary) : Numbers(sqrt(pow(real, 2) + pow(imaginary, 2))) {
        setImaginary(imaginary);
        setReal(real);
    }

    void Complex::setImaginary(const double imag) {
        m_imaginary = imag;

    }

    void Complex::setReal(const double real) {
        m_real = real;
    }

    std::ostream& operator<<(std::ostream& out, const Complex& Number) {
        if (Number.getImaginary() >= 0) {
            out << Number.getReal() << "+" << Number.getImaginary() << "i"; //3+1i
        } else if (Number.getImaginary() < 0)
            out << Number.getReal() << Number.getImaginary() << "i"; //3-1i 
        return out;
    }

    Complex operator+(const Complex& value1, const Complex& value2) {
        Complex result;
        result.setImaginary(value1.getImaginary() + value2.getImaginary());
        result.setReal(value1.getReal() + value2.getReal());
        return result;
    }

    Complex operator-(const Complex& value1, const Complex& value2) {
        Complex result;
        result.setImaginary(value1.getImaginary() - value2.getImaginary());
        result.setReal(value1.getReal() - value2.getReal());
        return result;
    }

    bool Complex::operator<(const Complex& right)const {
        bool res;
        if (getReal() < right.getReal() && getImaginary() < right.getImaginary())
            res = true;
        else if (getReal() == right.getReal() && getImaginary() < right.getImaginary())
            res = true;
        else if (getReal() == right.getReal() && getImaginary() > right.getImaginary())
            res = false;
        else if (getImaginary() == right.getImaginary() && getReal() < right.getReal())
            res = true;
        else if (getImaginary() == right.getImaginary() && getReal() > right.getReal())
            res = false;
        else res = Numbers::operator<(right);
        return res;
    }

    Complex& Complex::operator=(const Complex& rValue) {
        this->setReal(rValue.getReal());
        this->setImaginary(rValue.getImaginary());
        Numbers::operator=(rValue);
        return (*this);
    }





}