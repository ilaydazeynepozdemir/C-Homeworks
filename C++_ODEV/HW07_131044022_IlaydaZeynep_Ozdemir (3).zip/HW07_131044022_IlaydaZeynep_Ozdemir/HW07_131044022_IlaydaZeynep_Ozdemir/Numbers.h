/* 
 * File:   Numbers.h
 * Author: ilayda zeynep ozdemir
 *
 * Created on December 14, 2015, 12:07 AM
 */


#ifndef NUMBERS_H
#define	NUMBERS_H
#include <iostream>
namespace NUMBERS__ {
    //Constructor'i protected.
    //Objesi olusturulmasin diye
    //Cunku complex sinifinin constructorinda cagiriliyor
    //m_number uyesi complex siniflarin buyuklugunu alir
    //complexten tureyen siniflarinda sayi degerlerini alir
    //<< operatoru icinde virtual olan print fonksiyonu cagirilir
    //bu sayede hangi sinifin << operatoru kullanilacagi anlasilir

    class Numbers {
    public:
    protected://sadece bundan turetilenler ve turetilenlerin turetilmisleri kullanabilir
        Numbers();
        Numbers(double num);
        void set(const double num);

        double get()const {
            return m_number;
        }
      //  friend Numbers operator+(const Numbers& value1, const Numbers& value2); //override edilmeli
      //  friend Numbers operator-(const Numbers& value1, const Numbers& value2); //override edilmeli
        friend std::ostream& operator<<(std::ostream& out, const Numbers& number);
        Numbers& operator=(const Numbers& rValue);
        bool operator<(const Numbers& right)const;

    private:
        double m_number;



    };
}
#endif	/* NUMBERS_H */

