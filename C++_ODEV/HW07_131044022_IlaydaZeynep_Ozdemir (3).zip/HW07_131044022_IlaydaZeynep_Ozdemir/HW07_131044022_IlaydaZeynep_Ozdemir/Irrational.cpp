/* 
 * File:   Irrational.cpp
 * Author: ilayda zeynep ozdemir
 * 
 * Created on December 14, 2015, 12:21 AM
 */

#include "Irrational.h"
#include "Rational.h"
#include <iostream>
namespace NUMBERS__ {

    Irrational::Irrational() : Real(0) {
    }

    Irrational::Irrational(double irrNumber) : Real(irrNumber) {
    }

    std::ostream& operator<<(std::ostream& out, const Irrational& Number) {
        out.precision(8);
        out << Number.getReal();
        return out;
    }

    

}
