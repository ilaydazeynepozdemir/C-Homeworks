/* 
 * File:   Real.cpp
 * Author: ilayda zeynep ozdemir
 * 
 * Created on December 14, 2015, 12:13 AM
 */

#include "Real.h"
namespace NUMBERS__ {

    Real::Real() : Complex() {
    }

    Real::Real(double real) : Complex(real) {
    }

    std::ostream& operator<<(std::ostream& out, const Real& Number) {
        out << Number.getReal();
        return out;
    }

    Real& Real::operator=(const Real& rValue) {
        Complex::operator=(rValue);
        return (*this);
    }

    Real operator+(const Real& value1, const Real& value2) {
        Real result;
        result.setReal(value1.getReal() + value2.getReal());
        return result;
    }

    Real operator-(const Real& value1, const Real& value2) {
        Real result;
        result.setReal(value1.getReal() - value2.getReal());
        return result;
    }

}
