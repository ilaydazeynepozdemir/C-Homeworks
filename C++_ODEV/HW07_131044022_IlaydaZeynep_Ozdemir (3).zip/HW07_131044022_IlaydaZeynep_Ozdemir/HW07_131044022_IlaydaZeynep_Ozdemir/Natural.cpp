/* 
 * File:   Natural.cpp
 * Author: ilayda zeynep ozdemir
 * 
 * Created on December 14, 2015, 12:23 AM
 */

#include "Natural.h"
namespace NUMBERS__ {

    Natural::Natural() {
    }

    Natural::Natural(int num_natural) : Integer(num_natural) {
        if (num_natural < 0)
            setNom(0);
    }

    std::ostream& operator<<(std::ostream& out, const Natural& Number) {
        out << Number.getNom();
        return out;
    }

    Natural operator+(const Natural & value1, const Natural & value2) {
        Natural result;
        result = value1.getNom() + value2.getNom();
        return result;
    }

    Natural operator-(const Natural & value1, const Natural & value2) {
        Natural result;
        result = value1.getNom() + value2.getNom();
        return result;
    }

    Natural& Natural::operator=(const Natural& rValue) {
        Integer::operator=(rValue);
        return (*this);
    }

}