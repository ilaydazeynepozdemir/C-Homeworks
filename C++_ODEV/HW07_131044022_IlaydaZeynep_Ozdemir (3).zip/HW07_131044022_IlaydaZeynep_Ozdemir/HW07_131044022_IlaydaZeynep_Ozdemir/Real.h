/* 
 * File:   Real.h
 * Author: ilayda zeynep ozdemir
 *
 * Created on December 14, 2015, 12:13 AM
 */

#ifndef REAL_H
#define	REAL_H
#include "Complex.h"
namespace NUMBERS__ {
//complexten turemistir
    class Real : public Complex {
    public:
        Real();
        Real(double real);
        friend Real operator +(const Real& value1,const Real& value2);
        friend Real operator -(const Real& value1,const Real& value2);
        Real& operator=(const Real& rValue);
        friend std::ostream& operator<<(std::ostream& out, const Real& Number);
 

    };
}
#endif	/* REAL_H */

