/* 
 * File:   Natural.h
 * Author: ilayda
 *
 * Created on December 14, 2015, 12:23 AM
 */

#ifndef NATURAL_H
#define	NATURAL_H
#include "Integer.h"
namespace NUMBERS__ {

    class Natural : public Integer {
    public:
        Natural();
        Natural(int num_natural);
        friend std::ostream& operator<<(std::ostream& out, const Natural& Number);
        friend Natural operator+(const Natural & value1, const Natural & value2);
        friend Natural operator-(const Natural & value1, const Natural & value2);
        Natural& operator=(const Natural& rValue);
    private:
        int natNum;

    };
}
#endif	/* NATURAL_H */

