/* 
 * File:   Integer.h
 * Author: ilayda
 *
 * Created on December 14, 2015, 12:22 AM
 */

#ifndef INTEGER_H
#define	INTEGER_H
#include "Rational.h"
namespace NUMBERS__ {

    class Integer : public Rational {
    public:
        Integer();
        Integer(int num_int);
        friend std::ostream& operator<<(std::ostream& out, const Integer& Number);
        friend Integer operator+(const Integer & value1, const Integer & value2);
        friend Integer operator-(const Integer & value1, const Integer & value2);
        Integer& operator=(const Integer& rValue);
        
    private:

    };
}
#endif	/* INTEGER_H */

