/* 
 * File:   Rational.h
 * Author: ilayda
 *
 * Created on December 14, 2015, 12:18 AM
 */

#ifndef RATIONAL_H
#define	RATIONAL_H
#include "Real.h"


namespace NUMBERS__ {

    class Rational : public Real {
    public:
        Rational();
        Rational(int nom);
        Rational(int nom, int denom);
        Rational(double number);

        void setNom(const int nom);

        int getNom()const {
            return nominator;
        }
        void setDenom(const int denom);

        int getDenom()const {
            return denominator;
        }
        friend std::ostream& operator<<(std::ostream& out, const Rational& Number);
        friend Rational operator+(const Rational & value1, const Rational & value2);
        friend Rational operator-(const Rational & value1, const Rational & value2);
        Rational& operator=(const Rational& rValue);



    private:
        int nominator;
        int denominator;
        


    };
}
#endif	/* RATIONAL_H */
