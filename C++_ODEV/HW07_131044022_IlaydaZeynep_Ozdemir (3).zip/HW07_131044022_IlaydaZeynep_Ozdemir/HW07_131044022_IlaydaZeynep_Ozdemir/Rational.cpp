/* 
 * File:   Rational.cpp
 * Author: ilayda zeynep ozdemir
 * 
 * Created on December 14, 2015, 12:18 AM
 */

#include "Rational.h"
#include <iostream>
using namespace std;
namespace {
    int formatOfRational(double& number); //bolulu formata getirme

    int formatOfRational(double& number) {//aldigi double sayiyi rasyonele cevirir
        //Rational tempRat;
        int counter = 1;
        int temp;
        bool sign = false;

        while (!sign) {
            temp = number*counter;
            if (temp == (number * counter))
                sign = true;
            else
                ++counter;
        }
        return counter;
    }
}
namespace NUMBERS__ {

    Rational::Rational() : Real() {
        setNom(0);
        setDenom(1);
    }

    Rational::Rational(double number) : Real(number) {
        int counter = formatOfRational(number);
        setNom(number * counter);
        setDenom(counter);


    }

    Rational::Rational(int nom) : Real(nom) {
        setNom(nom);
        setDenom(1);
    }

    Rational::Rational(int nom, int denom) : Real(((nom * 1.0) / denom)) {
        setNom(nom);
        setDenom(denom);
    }

    Rational& Rational::operator=(const Rational& rValue) {
        Real::operator=(rValue);
        setNom(rValue.getNom());
        setDenom(rValue.getDenom());
        return (*this);
    }

    void Rational::setNom(const int nom) {
        nominator = nom;
    }

    void Rational::setDenom(const int denom) {
        if (denom != 0) {
            denominator = denom;
        } else if (denom == 0) {//DUZENLE
            cout << "Payda 0 verilemez!!" << endl;
            denominator = 1;
        }
    }

    std::ostream& operator<<(std::ostream& out, const Rational& Number) {
        if (Number.getNom() != 0)
            out << Number.getNom() << "/" << Number.getDenom();
        else if (Number.getNom() == 0) out << Number.getNom();
        return out;
    }

    Rational operator+(const Rational & value1, const Rational & value2) {
        Rational result;
        double temp;
        temp = value1.getReal() + value2.getReal(); //getReal() = nom/denom(1.0) degerine esdeger
        int counter = formatOfRational(temp);
        result.setNom(temp * counter);
        result.setDenom(counter);
        return result;
    }

    Rational operator-(const Rational & value1, const Rational & value2) {
        Rational result;
        double temp;
        temp = value1.getReal() - value2.getReal(); //getReal() = nom/denom(1.0) degerine esdeger
        int counter = formatOfRational(temp);
        result.setNom(temp * counter);
        result.setDenom(counter);
        return result;
    }
}
