/* 
 * File:   Imaginary.cpp
 * Author: ilayda zeynep ozdemir
 * 
 * Created on December 14, 2015, 12:16 AM
 */

#include "Imaginary.h"
#include "Complex.h"
namespace NUMBERS__ {

    Imaginary::Imaginary() : Complex() {

    }

    Imaginary::Imaginary(double Imag) : Complex(0, Imag) {
    }

    std::ostream& operator<<(std::ostream& out, const Imaginary& Number) {
        out << Number.getImaginary() << "i";
        return out;
    }

    Imaginary operator+(const Imaginary& value1, const Imaginary& value2) {
        Imaginary result;
        result.setImaginary(value1.getImaginary() + value2.getImaginary());
        return result;
    }

    Imaginary operator-(const Imaginary& value1, const Imaginary& value2) {
        Imaginary result;
        result.setImaginary(value1.getImaginary() - value2.getImaginary());
        return result;
    }

    Imaginary& Imaginary::operator=(const Imaginary& rValue) {
        Complex::operator=(rValue);
        return (*this);
    }
}
