/* 
 * File:   main.cpp
 * Author: ilayda zeynep ozdemir
 *
 * Created on December 14, 2015, 12:06 AM
 */

#include <cstdlib>
#include "Complex.h"
#include "Real.h"
#include "Imaginary.h"
#include "Rational.h"
#include "Irrational.h"
#include "Integer.h"
#include "Natural.h"
#include <iostream>
#include <math.h>


using namespace std;
using namespace NUMBERS__;

/*
 * 
 */

namespace {

    template<class S, class B, class D>
    void generalTest(S Text, B Num1, D Num2) {
        cout << Text << "      " << endl;
        cout << " " << Num1 << " --- " << Num2 << endl;
        cout << "toplamlari = " << Num1 + Num2 << endl;
        cout << "farklari = " << Num1 - Num2 << endl;
        if (Num1 < Num2)
            std::cout << Num1 << " < " << Num2 << std::endl;
        else std::cout << "  " << Num2 << " < " << Num1 << std::endl;
        cout << "---------------------" << endl;
    }
}

int main(int argc, char** argv) {
    cout << "HER TIPIN KENDI TIPINDEN BIR OBJEYLE TESTLERI" << endl;
    Complex compNum1(1, 2);
    Complex compNum2(2, -3);
    generalTest("Complex Number", compNum1, compNum2);

    Real realNum1(2);
    Real realNum2(-8);
    generalTest("Real Number", realNum1, realNum2);

    Imaginary imagNum1(5);
    Imaginary imagNum2(-7);
    generalTest("Imaginary Number", imagNum1, imagNum2);

    Rational ratNum1(3,4);
    Rational ratNum2(8.5);
    generalTest("Rational Number", ratNum1, ratNum2);

    Irrational irrNum1(sqrt(2));
    Irrational irrNum2(1.0 / 3);
    generalTest("Irrational - Irrational", irrNum1, irrNum2);

    Integer intNum1(-3);
    Integer intNum2(7);
    generalTest("Integer Number", intNum1, intNum2);

    Natural natNum1(7);
    Natural natNum2(5);
    generalTest("Natural Number", natNum1, natNum2);
    /////////////////////////////////////////////////

    cout << "COMPLEX'IN DIGER TIPLERLE TESTLERI" << endl; /////////
    generalTest("Complex Number - Real Number ", compNum1, realNum1);
    generalTest("Complex Number - Imaginary Number ", compNum1, imagNum1);
    generalTest("Complex Number - Rational Number ", compNum1, ratNum1);
    generalTest("Complex Number - Irrational Number ", compNum1, irrNum1);
    generalTest("Complex Number - Integer Number ", compNum1, intNum1);
    generalTest("Complex Number - Natural Number ", compNum1, natNum1);
    //////////////////////////////////////////////
    cout << endl << "IMAGINARY'NIN DIGER TIPLERLE TESTLERI" << endl;
    generalTest("Imaginary Number - Real Number ", imagNum1, realNum1);
    generalTest("Imaginary Number - Complex Number ", imagNum1, compNum1);
    generalTest("Imaginary Number - Rational Number ", imagNum1, ratNum1);
    generalTest("Imaginary Number - Irrational Number ", imagNum1, irrNum1);
    generalTest("Imaginary Number - Integer Number ", imagNum1, intNum1);
    generalTest("Imaginary Number - Natural Number ", imagNum1, natNum1);
    //////////////////////////////////////////////
     cout << endl << "REAL'IN DIGER TIPLERLE TESTLERI" << endl;
    generalTest("Real Number - Real Number ", realNum1, imagNum1);
    generalTest("Real Number - Complex Number ", realNum1, compNum1);
    generalTest("Real Number - Rational Number ", realNum1, ratNum1);
    generalTest("Real Number - Irrational Number ", realNum1, irrNum1);
    generalTest("Real Number - Integer Number ", realNum1, intNum1);
    generalTest("Real Number - Natural Number ", realNum1, natNum1);
    //////////////////////////////////////////////
     cout << endl << "RATIONAL'IN DIGER TIPLERLE TESTLERI" << endl;
    generalTest("Rational Number - Real Number ", ratNum1, imagNum1);
    generalTest("Rational Number - Complex Number ", ratNum1, compNum1);
    generalTest("Rational Number - Rational Number ", ratNum1, realNum1);
    generalTest("Rational Number - Irrational Number ", ratNum1, irrNum1);
    generalTest("Rational Number - Integer Number ", ratNum1, intNum1);
    generalTest("Rational Number - Natural Number ", ratNum1, natNum1);
    //////////////////////////////////////////////
    cout << endl << "INTEGER'IN DIGER TIPLERLE TESTLERI" << endl;
    generalTest("Integer Number - Real Number ", intNum1, realNum1);
    generalTest("Integer Number - Complex Number ", intNum1, compNum1);
    generalTest("Integer Number - Rational Number ", intNum1, ratNum1);
    generalTest("Integer Number - Irrational Number ", intNum1, irrNum1);
    generalTest("Integer Number - Imaginary Number ", intNum1, imagNum1);
    generalTest("Integer Number - Natural Number ", intNum1, natNum1);
    //////////////////////////////////////////////
    cout << endl << "NATURAL'IN DIGER TIPLERLE TESTLERI" << endl;
    generalTest("Natural Number - Real Number ", natNum1, realNum1);
    generalTest("Natural Number - Complex Number ", natNum1, compNum1);
    generalTest("Natural Number - Rational Number ", natNum1, ratNum1);
    generalTest("Natural Number - Irrational Number ", natNum1, irrNum1);
    generalTest("Natural Number - Imaginary Number ", natNum1, imagNum1);
    generalTest("Natural Number - Natural Number ", natNum1, intNum1);
    //////////////////////////////////////////////

    return 0;
}

