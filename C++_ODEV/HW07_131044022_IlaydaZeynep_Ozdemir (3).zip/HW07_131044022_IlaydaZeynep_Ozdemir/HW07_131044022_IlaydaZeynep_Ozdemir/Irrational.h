/* 
 * File:   Irrational.h
 * Author: ilayda
 *
 * Created on December 14, 2015, 12:21 AM
 */

#ifndef IRRATIONAL_H
#define	IRRATIONAL_H
#include "Real.h"
namespace NUMBERS__ {
    //Realden turetilmistir
    //bu sinif tam olusturulmadi
    //default + - operatorlerini kullaniyor

    class Irrational : public Real {
    public:
        Irrational();
        Irrational(double irrNumber);
        friend std::ostream& operator<<(std::ostream& out, const Irrational& Number);
        //friend Irrational operator+(const Irrational & value1, const Irrational & value2);
        //friend Irrational operator-(const Irrational & value1, const Irrational & value2);
        //double get_PI()const;
        //double get_e()const;


    private:

    };
}
#endif	/* IRRATIONAL_H */

