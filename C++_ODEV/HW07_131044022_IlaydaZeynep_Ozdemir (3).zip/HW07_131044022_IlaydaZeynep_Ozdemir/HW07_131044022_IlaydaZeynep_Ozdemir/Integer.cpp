/* 
 * File:   Integer.cpp
 * Author: ilayda zeynep ozdemir
 * 
 * Created on December 14, 2015, 12:22 AM
 */

#include "Integer.h"
#include <iostream>
namespace NUMBERS__ {

    Integer::Integer() : Rational(0) {
    }

    Integer::Integer(int num_int) : Rational(num_int) {

    }

    std::ostream& operator<<(std::ostream& out, const Integer& Number) {
        out << Number.getNom();
        return out;
    }

    Integer operator+(const Integer & value1, const Integer & value2) {
        Integer result;
        result = value1.getNom() + value2.getNom();
        return result;
    }

    Integer operator-(const Integer & value1, const Integer & value2) {
        Integer result;
        result = value1.getNom() + value2.getNom();
        return result;
    }

    Integer& Integer::operator=(const Integer& rValue) {
        Rational::operator=(rValue);
        return (*this);
    }
}
