/* 
 * File:   Complex.h
 * Author: ilayda
 *
 * Created on December 14, 2015, 12:09 AM
 */

#ifndef COMPLEX_H
#define	COMPLEX_H
#include "Numbers.h"
namespace NUMBERS__ {
    //complex sinifi numberstan turemistir

    class Complex : public Numbers {
    public:
        Complex();
        Complex(double real);
        Complex(double real, double imaginary);
        void setImaginary(const double imag);
        void setReal(const double real);

        double getImaginary()const {
            return m_imaginary;
        }

        double getReal()const {
            return m_real;
        }

        friend Complex operator+(const Complex& value1, const Complex& value2);
        friend Complex operator-(const Complex& value1, const Complex& value2);
        friend std::ostream& operator<<(std::ostream& out, const Complex& Number);
        bool operator<(const Complex& right)const;
        Complex& operator=(const Complex& rValue);


    private:
        double m_imaginary;
        double m_real;

    };
}
#endif	/* COMPLEX_H */

