/* 
 * File:   Imaginary.h
 * Author: ilayda zeynep ozdemir
 *
 * Created on December 14, 2015, 12:16 AM
 */

#ifndef IMAGINARY_H
#define	IMAGINARY_H
#include "Complex.h"
namespace NUMBERS__ {
    //complexten turemistir

    class Imaginary : public Complex {
    public:
        Imaginary();
        Imaginary(double Imag);
        friend std::ostream& operator<<(std::ostream& out, const Imaginary& Number);
        friend Imaginary operator+(const Imaginary& value1, const Imaginary& value2);
        friend Imaginary operator-(const Imaginary& value1, const Imaginary& value2);
        Imaginary& operator=(const Imaginary& rValue);
    private:

    };
}
#endif	/* IMAGINARY_H */

