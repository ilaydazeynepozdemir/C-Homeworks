package hw09_131044022_ilaydazeynep_ozdemir;

import static java.lang.Math.pow;

/**
 *
 * @author ilayda zeynep ozdemir
 */
public class Polynomial {

    /**
     * katsayilari tutan array
     */
    private double[] coefArray;
    /**
     * dereceyi tutan eleman
     */
    private int n;//n: x^n'nin n'i

    //toString fonksiyonunun bir parcasidir private olarak yazildir
    //cunku bunun disaridan cagirilmamasi gerekir
    private String toString_helper(double coef_, int exp_) {
        if (coef_ == 0) {
            return "0";
        } else if (coef_ == 1 && exp_ != 0) {
            return "x^" + exp_;
        } else if (exp_ == 1) {//
            return String.format("%.2f", coef_) + "x";
        } else if (exp_ == 0) {
            return "" + String.format("%.2f", coef_);
        } else if (coef_ == -1) {
            return "-x^" + exp_;
        } else {
            return String.format("%.2f", coef_) + "x^" + exp_;
        }
    }

    /**
     * constructor = no-parameter constructor
     */
    public Polynomial() {
        coefArray = new double[0];
        setDegree(0);

    }

    /**
     * constructor = double arrayi alip polinomu yapilandiran constructor
     *
     * @param takenArray
     */
    public Polynomial(double[] takenArray) {
        setCoefs(takenArray);
        setDegree(takenArray.length - 1);
    }

    /**
     * polinomun derecesini set eder
     *
     * @param degreeN
     */
    public void setDegree(int degreeN) {
        n = degreeN;
    }

    /**
     * polinomun derecesini return eder
     *
     * @return polinomun n(derece) degerini return eder
     */
    public int getDegree() {
        return n;
    }

    /**
     * polinomun tum arrayini set eder
     *
     * @param takenArray
     */
    public void setCoefs(double[] takenArray) {
        coefArray = new double[takenArray.length];
        for (int i = 0; i < takenArray.length; ++i) {
            coefArray[i] = takenArray[i];
        }
    }

    /**
     * coefArrayin referansini donduruyor. coefArray, butun katsayilari iceren
     * bir double array
     *
     * @return katsayilari iceren double[] return eder
     */
    public double[] getCoefs() {//referansi donuyor
        return coefArray;
    }

    /**
     * verilen katsayi ve derece ile coefArray icinin belirtilen elemani
     * dolduruluyor
     *
     * @param takeCoef
     * @param degree_n
     */
    public void setCoef(double takeCoef, int degree_n) {//tek tek arrayi set eder
        coefArray[degree_n] = takeCoef;
    }

    /**
     * belirtilen,istenen yerdeki katsayiyi return ediliyor
     *
     * @param degree_n
     * @return arrayin degree_n'inci elemanini return eder
     */
    public double getCoef(int degree_n) {
        return coefArray[degree_n];
    }

    /**
     * polinomu string hale getiriyor
     *
     * @return polinomun string hali
     */
    public String toString() {//redifines toString methods
        String polynom = "";
        int d = 0;
        for (int i = coefArray.length - 1; i >= 0; --i) {
            //System.out.printf("%f ", coefArray[i]);
            if (getCoef(i) != 0) {

                if (i != coefArray.length - 1) {
                    polynom += " + ";
                }
                polynom += "(";
                polynom += toString_helper(getCoef(i), getDegree() - d);
                polynom += ")";
            }
            ++d;
        }
        return polynom;
    }

    /**
     * ana polinomla verilen polinom esit mi diye kontrol ediliyor
     *
     * @param other
     * @return esitse true degilse false return eder
     */
    public boolean equals(Polynomial other) {//redefines equals methods
        boolean eql = false;
        if (getDegree() == other.getDegree()) {
            eql = true;
        }
        if (eql == true) {
            for (int i = 0; i < getDegree() + 1; ++i) {
                if(getCoef(i) == other.getCoef(i))
                    eql = true;
                else eql = false;    
            }
        }
        return eql;
    }

    /**
     * polinomun sonucu return ediliyor verilen x degerindeki
     *
     * @param x
     * @return polinomun x degeri yerine konuluncaki sonucu return eder
     */
    public double resultOfpolynom(double x) {
        double res = 0.0;
        for (int i = 0; i < coefArray.length; ++i) {
            res += getCoef(i) * (pow(x, getDegree() - i));
        }
        return res;
    }

    /**
     * iki polinomun toplami return ediliyor
     *
     * @param other
     * @return toplama sonucundaki polinomu return eder
     */
    public Polynomial add(Polynomial other) {//toplama
        double[] addArr = {0};
        if (this.getDegree() >= other.getDegree()) {
            addArr = new double[getDegree() + 1];
        } else {
            addArr = new double[other.getDegree() + 1];
        }

        for (int i = 0; i < this.getDegree() + 1; ++i) {
            addArr[i] += getCoef(i);
        }
        for (int i = 0; i < other.getDegree() + 1; ++i) {
            addArr[i] += other.getCoef(i);
        }
        return new Polynomial(addArr);
    }

    /**
     * iki polinomun farki return ediliyor
     *
     * @param other
     * @return cikarma sonucundaki polinomu return eder
     */
    public Polynomial substracts(Polynomial other) {//cikarma
        double[] subsArr = {0};
        if (this.getDegree() >= other.getDegree()) {
            subsArr = new double[getDegree() + 1];
        } else {
            subsArr = new double[other.getDegree() + 1];
        }
        for (int i = 0; i < this.getDegree() + 1; ++i) {
            subsArr[i] += getCoef(i);
        }
        for (int i = 0; i < other.getDegree() + 1; ++i) {
            subsArr[i] -= other.getCoef(i);
        }
        return new Polynomial(subsArr);
    }

    /**
     * iki polinomun carpimi return ediliyor
     *
     * @param other
     * @return carpma sonucundaki polinomu return eder
     */
    public Polynomial multiplies(Polynomial other) {//carpma
        double[] multArr;
        int deg = 0;
        multArr = new double[getDegree() + other.getDegree() + 1];
        //arti 1 nin sebebi 0.eleman

        for (int i = 0; i < this.getDegree() + 1; ++i) {
            for (int j = 0; j < other.getDegree() + 1; ++j) {
                deg = i + j;//usleri topluyoruz
                multArr[deg] += getCoef(i) * other.getCoef(j);
            }
        }
        return new Polynomial(multArr);
    }
}
