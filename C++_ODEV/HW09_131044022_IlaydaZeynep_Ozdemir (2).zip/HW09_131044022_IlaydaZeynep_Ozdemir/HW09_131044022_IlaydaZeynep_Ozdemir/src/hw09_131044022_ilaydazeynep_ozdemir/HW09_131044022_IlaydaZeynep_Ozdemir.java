/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw09_131044022_ilaydazeynep_ozdemir;

/**
 *
 * @author ilayda zeynep ozdemir
 */
public class HW09_131044022_IlaydaZeynep_Ozdemir {

    /**
     * test
     * @param args 
     */
    public static void main(String[] args) {
        double[] test1 = new double[5];
        double[] test5 = new double[5];
        double[] test9 = new double[5];
        double[] test10 = new double[5];
        for (int i = 0; i < test1.length; ++i) {
            test1[i] = i - 1;
            test5[i] = i * (1.3);
            test9[i] = i * (1.8);
            test10[i] = i * (1.7);
        }

        double[] test2 = new double[3];
        double[] test6 = new double[3];
        for (int i = 0; i < test2.length; ++i) {
            test2[i] = i + 1;
            test6[i] = i;
        }

        double[] test3 = new double[8];
        double[] test7 = new double[8];
        for (int i = 0; i < test3.length; ++i) {
            test3[i] = i * 2;
            test7[i] = i + 2;
        }

        double[] test4 = new double[2];
        double[] test8 = new double[2];
        for (int i = 0; i < test4.length; ++i) {
            test4[i] = i + 2;
            test8[i] = ((i + 5) * (1.0)) / 2;
        }

        test(test1, test2);
        test(test3, test4);
        test(test5, test6);
        test(test7, test8);
        test(test9, test10);
        
        test(test10, test10);
        test(test5,test4);
        test(test3,test7);
        test(test1,test1);

    }

    //test fonksiyonu 
    //ekrana polinomlari basar
    public static void test(double[] coef1, double[] coef2) {
        Polynomial poly1 = new Polynomial(coef1);
        Polynomial poly2 = new Polynomial(coef2);

        System.out.printf("Birinci polinom = %s\n", poly1.toString());
        System.out.printf("Ikinci polinom = %s\n", poly2.toString());
       //
        boolean res = poly1.equals(poly2);
        if(res==true)
            System.out.printf("iki polinom esit\n");
        else 
            System.out.printf("iki polinom esit degil\n");
        System.out.printf("P1(%d) = %.0f\n", 2, poly1.resultOfpolynom(1));
        System.out.printf("P2(%d) = %.0f\n", 1, poly2.resultOfpolynom(1));
        System.out.printf("Iki polinomun toplami = %s \n", poly1.add(poly2).toString());
        System.out.printf("Iki polinomun farki = %s \n", poly1.substracts(poly2).toString());
        System.out.printf("Iki polinomun carpimi = %s \n", poly1.multiplies(poly2).toString());
        
        
        
        System.out.printf("##############################################################\n");
        
    }

}
