/* 
 * File:   Reversi.cpp
 * Author: ilayda Zeynep Ozdemir 131044022
 * 
 * Created on November 23, 2015, 12:07 PM
 */
#include "Reversi.h"
#include "Cell.h"
#include <cstdlib>
#include <iostream>
#include <string>
#include<fstream>
#include <vector>



using namespace std;
int Reversi::LivingCell = 0;

Reversi::Reversi() {
    setSizesTable(4, 4); //parametresiz olusturulursa 4x4'luk bir tablo olusur

}

Reversi::Reversi(int Coloum_and_Row) {
    setSizesTable(Coloum_and_Row, Coloum_and_Row);
}

Reversi::Reversi(int Row, int Coloum) {
    setSizesTable(Row, Coloum);
}

void Reversi::setSizesTable(const int row, const int col) {
    sizeOfRow = row;
    sizeOfCol = col;
    gameCells.resize(row);
    for (int i = 0; i < gameCells.size(); ++i)
        gameCells.at(i).resize(0); //resize 1 yaptigimda bos hucre koyuyor
}

//integer bir sayiyi stringe donusturuyor
//global gibi yazdim

string Reversi::myItoa(int IntNum)const {
    string stringNum;
    while (IntNum > 0) {
        int last_digit = IntNum % 10;
        IntNum /= 10;
        char i = '0'; //'0' int degeri 48 oldugu icin bunu kullaniyorum
        i = i + last_digit;
        stringNum = i + stringNum; //her yeni basamagi sayinin string haline ekliyor
    }
    return stringNum;
}

//tek boyutlu vectorun maximum degerini bulup indexini donduruyor
//globalgibi yazdim

int Reversi::FindMaxNum_InVector(const vector<int>& vector_, int size)const {
    int max = 0;
    int index;
    for (int i = 0; i < size; ++i) {
        if (max <= vector_.at(i)) {
            max = vector_.at(i);
            index = i;
        }
    }
    return index;
}

int Reversi::getLivingCell() {
    return Reversi::LivingCell;
}

void Reversi::testForReversi() {

    setStartVector();

    cout << "~~~Oyun tablosu~~~" << endl << (*this) << endl << endl;
    cout << "test[5A] = " << (*this)["5A"] << endl;
    if ((*this)["5A"].getIntX() == -1000 && (*this)["5A"].getY() == -1000)
        cout << "Bu hucre oyun tablosunda yoktur!(-1000,-1000)" << endl;

    cout << "test(2,B) " << (*this)(2, "B") << endl; //vektorde 1,b olarak tutuluyor
    if ((*this)(2, "B").getIntX() == -1000 && (*this)(2, "B").getY() == -1000)
        cout << "Bu hucre oyun tablosunda yoktur!(-1000,-1000)" << endl;

    cout << "test(4,D) " << (*this)(4, "d") << endl;
    if ((*this)(4, "d").getIntX() == -1000 && (*this)(4, "d").getY() == -1000)
        cout << "Bu hucre oyun tablosunda yoktur!(-1000,-1000)" << endl;

    cout << "test(5,D) " << (*this)(5, "d") << endl;
    if ((*this)(5, "d").getIntX() == -1000 && (*this)(5, "d").getY() == -1000)
        cout << "Bu hucre oyun tablosunda yoktur!(-1000,-1000)" << endl;

    Cell forPlay;
    cout << "oynamak icin hucre alin" << endl;
    cin>>forPlay; //Cell'in >> operatoru
    cout << "Aldigin hucre" << forPlay << endl; //Cell'in <<

     (*this)+=forPlay;



}

Cell& Reversi::operator[](string position) {

    for (int i = 0; i < position.length(); ++i)
        position.at(i) = tolower(position.at(i));
    string temp, forIntPart;
    for (int i = 0; i < position.size(); ++i) {
        for (int j = 0; j < 23; ++j) {
            if (position.at(i) == letterss[j].at(0)) {
                temp += position.at(i);
                for (int k = i; k < position.size(); ++k) {
                    if (position.at(k) != temp.at(0))
                        forIntPart += position.at(k);
                }
            }
        }
    }
    Cell tempCell(atoi(position.c_str()) - 1, temp + forIntPart);
    for (int i = 0; i < gameCells.size(); ++i) {
        for (int j = 0; gameCells.at(i).size(); ++j) {
            if (gameCells.at(i).at(j).getY() == atoi(position.c_str()) - 1 &&
                    gameCells.at(i).at(j).getX() == (temp + forIntPart))
                return gameCells.at(i).at(j);
            else {//bos ise
                Cell *newCell = new Cell;
                newCell->setY(-1000);
                newCell->setX("w"); //w'nin degerini setIntX()de -1000 yaptim
                return (*newCell);
            }
        }
    }
}

Cell& Reversi::operator()(int posY, string posX) {
    for (int i = 0; i < posX.length(); ++i)
        posX.at(i) = tolower(posX.at(i));
    for (int i = 0; i < gameCells.size(); ++i) {
        for (int j = 0; gameCells.at(i).size(); ++j) {
            /*cout<<gameCells.at(i).at(j).getY()<<"-"<<gameCells.at(i).at(j).getX()<<endl;
            cout<<posY-1 <<"-"<<posX<<endl;*/
            if (gameCells.at(i).at(j).getY() == (posY - 1) &&
                    gameCells.at(i).at(j).getX() == posX) {

                return gameCells.at(i).at(j);
            } else {//bos ise yeni hucre olusturup yolluyor
                Cell *newCell = new Cell;
                newCell->setY(-1000);
                newCell->setX("w");
                newCell->setPointX_O("X");
                return (*newCell);
            }
        }
    }

}
//display fonksiyonunu kopyalayip duzenledim
//ama yanlis basiyor hala

std::ostream& operator<<(std::ostream& outgame, const Reversi game) {
    int countR = 0;
    int i = 0;
    int col = 0;
    int coloum = 1;
    for (int row = 0; row <= game.getRow(); ++row) {
        for (col = 0; col <= game.getCol(); ++col) {

            if (row == 0 && col == 0)
                outgame << "- ";
            else if (row == 0 && col < 23)//coloum harfleri
                outgame << letterss[col - 1];
            else if (row == 0 && col >= 23) {

                if (col / 23 >= coloum) {//23/23=1
                    ++coloum;
                }
                outgame << letterss[col % 23] + game.myItoa(coloum - 1) + " ";

            } else if (col == 0) {//row
                if (row < 10)
                    outgame << row << " ";
                else
                    outgame << row;
            } else outgame << ".";

            for (int i = 0; i < game.gameCells.size(); ++i) {//
                for (int j = 0; j < game.gameCells.at(i).size(); ++j) {

                    if (game.gameCells.at(i).at(j).getY() == row - 1) {//son eleman degilse vktordeki
                        if (j == 0)//satirdaki ilk elemansa basina nokta
                            for (int k = game.gameCells.at(i).at(j).getIntX(); k > 0; --k)
                                outgame << ".";

                        if (game.gameCells.at(i).at(j).getIntX() != col - 1)
                            outgame << game.gameCells.at(i).at(j).getPointX_O();

                        if (j + 1 != game.gameCells.at(i).size()) {//satirdaki son eleman degilse 
                            int numOfPoint = game.gameCells.at(i).at(j + 1).getIntX() - game.gameCells.at(i).at(j).getIntX();
                            for (int p = 0; p < numOfPoint - 1; ++p)
                                outgame << ".";
                        }

                        if (j + 1 == game.gameCells.at(i).size()) {//vektor satirindaki satirdaki son elemansa
                            for (int p = j + 1; p < game.getRow() - p; ++p)
                                outgame << ".";
                        }
                        col = game.getCol() + 1; //ayni satir farkli coloumlari yazdirip donguden cikiyor
                    }
                }
            }
        }
        outgame << endl;
    }
    return outgame;
}

Reversi Reversi::operator+=(Cell forUser) {
    //play(forUser);//ben play fonksiyonunda position yerine cell almistim
    //4.odevde
    bool is_avail;
    vector<int> lengths;
    lengths.resize(11);
    --forUser;// mesela 2 d O girilince 1 d O algilanmali
    //cout<<forUser<<endl;
    int sign;
    is_avail = available(lengths, forUser);
    if (is_avail == true) {
        sign = FindMaxNum_InVector(lengths, 11);
        //cout<<sign<<endl;
        if (sign < 10)
           pushNewLivingCell(forUser, forUser.getY(), lengths.at(sign), sign);
        cout<<(*this);
    }else cout<<"uygun degil"<<endl;
    
    return (*this);
}

void Reversi::setStartVector() {
    Cell tempX1, tempO1, tempX2, tempO2;

    int coloum = 1;
    string forX;
    for (int i = 0; i <= getRow(); ++i) {
        for (int j = 0; j <= getCol(); ++j) {
            if (getCol() < 23) {
                tempX1.setX(letterss[(getCol() - 1) / 2]);
                tempO1.setX(letterss[(getCol() - 1) / 2 + 1]);
                tempO2.setX(letterss[(getCol() - 1) / 2]);
                tempX2.setX(letterss[(getCol() - 1) / 2 + 1]);

            } else if (getCol() >= 23) {
                if (getCol() / 23 == coloum)
                    ++coloum;
                //forX=letterss[(j ) % 23] + myItoa((coloum - 1)) + " ";
                tempX1.setX(letterss[(j) % 23 / 2] + myItoa((coloum - 1)) + " ");
                tempO1.setX(letterss[(j) % 23 / 2 + 1] + myItoa((coloum - 1)) + " ");
                tempO2.setX(letterss[(j) % 23 / 2] + myItoa((coloum - 1)) + " ");
                tempX2.setX(letterss[(j) % 23 / 2 + 1] + myItoa((coloum - 1)) + " ");

            }
        }
    }
    tempX1.setY((getRow() - 1) / 2);
    tempX1.setPointX_O("O");
    gameCells.at(tempX1.getY()).push_back(tempX1);


    tempO1.setY((getRow() - 1) / 2);
    tempO1.setPointX_O("X");
    gameCells.at(tempO1.getY()).push_back(tempO1);


    tempO2.setY((getRow() - 1) / 2 + 1);
    tempO2.setPointX_O("X");
    gameCells.at(tempO2.getY()).push_back(tempO2);


    tempX2.setY((getRow() - 1) / 2 + 1);
    tempX2.setPointX_O("O");
    gameCells.at(tempX2.getY()).push_back(tempX2);
    Reversi::LivingCell += 4; //her baslangicta +4'le
}

//iki Cell hucresinin yerini degistirir

void Reversi::SwapCells(Cell& Cell1, Cell& Cell2) {
    Cell temp;

    temp.setPointX_O(Cell1.getPointX_O());
    temp.setX(Cell1.getX());
    temp.setY(Cell1.getY());
    Cell1.setX(Cell2.getX());
    Cell1.setY(Cell2.getY());
    Cell1.setPointX_O(Cell2.getPointX_O());
    Cell2.setX(temp.getX());
    Cell2.setY(temp.getY());
    Cell2.setPointX_O(temp.getPointX_O());
}

//tek boyutlu bir Cell vektorunu siralar

void Reversi::sortOfCells_forRow(vector<Cell>& RowVector, int currentSizeCol) {
    Cell temp;
    for (int i = 0; i < currentSizeCol; ++i) {//sutun icin
        for (int j = i; j < currentSizeCol; ++j) {

            if ((RowVector.at(i).getY() == RowVector.at(j).getY()) && (RowVector.at(i).getX() != RowVector.at(j).getX())) {
                if (RowVector.at(i).getIntX() > RowVector.at(j).getIntX()) {
                    SwapCells(RowVector.at(i), RowVector.at(j)); //j yi tempe kopyalar j ye i yi atar i ye j yi 
                }
            } else if (RowVector.at(i).getX() == RowVector.at(j).getX() && RowVector.at(i).getY() != RowVector.at(j).getY());
        }
    }
}

inline int Reversi::getCol()const {
    return sizeOfCol;
};

inline int Reversi::getRow()const {
    return sizeOfRow;
};

void Reversi::write(const char* outputFile) const {
    ofstream out;
    string forWrite;
    out.open(outputFile);
    if (!out) {
        cerr << "Dosya yok!" << endl;
        exit(1);
    } else {
        out << getRow() << " " << getCol() << " ";
        for (int i = 0; i < gameCells.size(); ++i) {
            for (int j = 0; j < gameCells.at(i).size(); ++j) {
                out << gameCells.at(i).at(j).getY() << " ";
                out << gameCells.at(i).at(j).getX() << " ";
                out << gameCells.at(i).at(j).getIntX() << " ";
                out << gameCells.at(i).at(j).getPointX_O() << " ";
            }
        }
    }
    out.close();
}

void Reversi::read(const char* inputFile) {
    Cell temp;
    ifstream input;
    input.open(inputFile);
    if (!input) {
        cerr << "Dosya yok!" << endl;
        exit(1);
    } else {
        int tempY;
        string tempX;
        int tempIntX;
        string tempXO;
        int Row, Col;
        input>>Row;
        input>>Col;
        setRow(Row);
        gameCells.resize(Row);
        for (int k = 0; k < gameCells.size(); ++k) {
            gameCells.at(k).resize(0); //yeni olusan digerinin ustune olusmasin diye
        }
        setCol(Col);
        while (!input.eof()) {
            input >> tempY;
            temp.setY(tempY);

            input >> tempX;
            temp.setX(tempX);

            input >> tempIntX;

            input >> tempXO;
            temp.setPointX_O(tempXO);
            if (!input.eof()) {
                for (int i = 0; i < gameCells.size(); ++i) {
                    if (temp.getY() == i) {
                        gameCells.at(i).push_back(temp);
                        ++LivingCell;
                    }
                }
            }
        }
        input.close();
    }
    for (int i = 0; i < gameCells.size(); ++i)
        sortOfCells_forRow(gameCells.at(i), gameCells.at(i).size());
}

void Reversi::play(Cell & user) {//user icin
    int position_Y;
    string position_YX;
    string position_X;
    bool is_avail = true;
    vector <int> lengths;
    lengths.resize(11);
    int sign = 0;

    do {
        do {//kullanicidan alma kismi ve aldigi stringi anlamlandirma 
            cout << "oynamak istediginiz hucrenin koordinatlarini giriniz" << endl;
            cin>>position_YX; // c_str'yi atoi string tipini kabul etmedigi icin kullandim
            position_Y = atoi(position_YX.c_str());
            user.setY(position_Y - 1);

            for (int j = 0; j < position_YX.length(); ++j) {
                for (int i = 0; i < 23; ++i) {
                    //tolower int donuyor bu nedenle letters'in elemanlarinda da 
                    //tolower fonksiyonunu kullandim
                    if (tolower(position_YX[j]) == tolower(letterss[i][0])) {
                        //letterss[i][0] tolower char aliyor lettersin ilk elemaninin 
                        //istedigimiz karakter old biliyorum.bu nedenle [i][0]i yolladim
                        for (int k = j; k < position_YX.length(); ++k) {
                            position_X += (position_YX[k]); //position_X'e a25 gibi olan kisimi dolduruyor
                        }
                        user.setX(position_X);
                        //ornegin a'nin 1 b'nin 2...
                        //i 0 dan basladigi icin bir fazlasini yolladim
                    }
                }
            }
        } while (user.getIntX() > getCol() || user.getY() > getRow());
        user.setPointX_O("O");

        for (int i = 0; i < gameCells.size(); ++i)
            sortOfCells_forRow(gameCells.at(i), gameCells.at(i).size());
        is_avail = available(lengths, user);
        /*for(int i=0;i<11;++i)
            cout<<i<<lengths.at(i)<<endl;*/


    } while (is_avail == false);
    sign = FindMaxNum_InVector(lengths, 11);
    if (sign < 10)
        pushNewLivingCell(user, user.getY(), lengths.at(sign), sign);
}

void Reversi::play() {//computer icin
    vector<int> lengths;
    lengths.resize(11);
    bool avail = false;
    vector<int> BestX_Side;
    vector<int> Best_Xlengths;
    vector<Cell> BestX;

    for (int i = 0; i < gameCells.size(); ++i) {
        int coloum = 1;
        for (int j = 0; j < gameCells.at(i).size(); ++j) {

            if (gameCells.at(i).at(j).getPointX_O() == "X") {
                computer.setPointX_O(gameCells.at(i).at(j).getPointX_O());

                computer.setY(gameCells.at(i).at(j).getY());
                computer.setX(gameCells.at(i).at(j).getX());

                avail = available(lengths, computer);
                //for(int i=0;i<11;++i)
                //  cout<<i<<lengths.at(i)<<endl;

                if (avail == true) {
                    int index = FindMaxNum_InVector(lengths, 11); //her X icin en buyuk hamlesinin indexi
                    BestX_Side.push_back(index); //her X icin en buyuk hamlesinin indexi tutar
                    Best_Xlengths.push_back(lengths[index]); //her X in en buyuk hamlesinin uzunlugunu
                    BestX.push_back(computer);
                }
            }
        }
    }



    int max = FindMaxNum_InVector(Best_Xlengths, Best_Xlengths.size());
    //cout << "max" << max << "-" << Best_Xlengths.at(max) << "-" << BestX.at(max).getY() << "-" << BestX.at(max).getX() << "-sign" << BestX_Side.at(max) << endl;

    //available'da dolan 8 tarafi tutan vectorden en buyuk length olani seciliyor

    convertFormat(Best_Xlengths.at(max), BestX_Side.at(max)); //
    //push fonksiyonuna yollamak icin formatini degistirip tarafini da degistiriyoruz
    switch (BestX_Side.at(max)) {//tarafini user tipindeki tarafa ceviriyorum
        case 2: BestX_Side.at(max) = 8;
            break;
        case 8:BestX_Side.at(max) = 2;
            break;
        case 6:BestX_Side.at(max) = 4;
            break;
        case 4:BestX_Side.at(max) = 6;
            break;
        case 3:BestX_Side.at(max) = 7;
            break;
        case 7:BestX_Side.at(max) = 3;
            break;
        case 1:BestX_Side.at(max) = 9;
            break;
        case 9:BestX_Side.at(max) = 1;
            break;
    }
    //vektore eklemek icin
    pushNewLivingCell(computer, computer.getY(), Best_Xlengths.at(max), BestX_Side.at(max));
}
//koordinatlarini user tipindeki koordinatlara ceviriyor

void Reversi::convertFormat(int length, int side) {


    if (side == 6 || side == 3 || side == 9) {
        if (this->computer.getIntX() + length + 1 < 23)
            computer.setX(letterss[computer.getIntX()]);
        else
            computer.setX(letterss[computer.getIntX() % 23] + myItoa(computer.getIntX() - 1));
        //Y koordinati ve PointX_O degismiyor//6 iken
    }
    if (side == 4 || side == 1 || side == 7) {
        if (this->computer.getIntX() - length < 23)
            computer.setX(letterss[computer.getIntX()]);
        else
            computer.setX(letterss[computer.getIntX() % 23] + myItoa(computer.getIntX() - 1));
        //Y koordinati ve PointX_O degismiyor//4 iken
    }
    if (side == 8 || side == 9 || side == 7) {
        //setX, X ve PointX_O degismez // 8 ise
        computer.setY(this->computer.getY() - length - 1);
    }
    if (side == 2 || side == 3 || side == 1) {
        //setX , X,PointX_O degismez// 2 iken
        computer.setY(this->computer.getY() + length + 1);
    }

}

int Reversi::menuOfGame() {
    int option = 0;
    string saveContinueFile;
    do {
        cout << endl << "0-Oyuna yeni basladiysaniz 0'i tuslayin" << endl;
        cout << "1-Oynanan oyuna devam etmek icin 1'i tuslayin" << endl;
        cout << "2-Oynanan oyunu bitirip kaydetmek isterseniz 2'yi tuslayin" << endl;
        cout << "3-Baska bir oyunu oynamak isterseniz 3'u tuslayin" << endl;
        cout << "4-Oyunlari karsilastirmak isterseniz 4'u tuslayin" << endl;
        cin>>option;

    } while (option != 0 && option != 1 && option != 2 && option != 3 && option != 4);

    switch (option) {
        case 0: cout << "Tablo boyutunu belirlemek isterseniz 1'i tuslayin" << endl;
            //tablo boyutlari belirlenmek istenmezse constuctorda olan kabul edilir
            int decide;
            char temp_r[10];
            char temp_c[10];
            cin >> decide;
            if (decide == 1) {
                do {
                    cout << "Tablonun satir sayisini giriniz:";
                    cin >>temp_r;
                    cout << "Tablonun sutun sayisini giriniz:";
                    cin>>temp_c;
                    setSizesTable(atoi(temp_r), atoi(temp_c));
                    if (atoi(temp_r) < 4 || atoi(temp_c) < 4)
                        cout << "duzgun bir oyun olabilmesi icin en az 4x4'luk girmelisiniz" << endl;
                } while (atoi(temp_r) < 4 || atoi(temp_c) < 4);
            }
            setStartVector();
            cout << "~~~~Yasayan hucre sayisi=" << Reversi::LivingCell << endl;
            break;
        case 1: cout << "~~~~Yasayan hucre sayisi=" << Reversi::LivingCell << endl;
            break;
        case 2:
            setStartVector();
            cout << "Oyunu kaydedeceginiz dosya adini girin(.txt seklinde):";
            cin>>saveContinueFile;
            cout << endl;
            write(saveContinueFile.c_str());
            cout << "~~~~Yasayan hucre sayisi=" << Reversi::LivingCell << endl;
            exit(0);
            break;
        case 3:
            int press;
            cout << "Guncel oyunu kaydetmek isterseniz 0'a basin" << endl;
            cin>>press;
            if (press == 0) {
                cout << "Kayit icin dosya adi(.txt seklinde):";
                cin>>saveContinueFile;
                cout << endl;
                write(saveContinueFile.c_str());
            }
            cout << "Oynamak istediginiz oyunun dosya adini giriniz(.txt seklinde)" << endl;
            cin>>saveContinueFile;
            read(saveContinueFile.c_str());
            cout << "~~~~Yasayan hucre sayisi=" << Reversi::LivingCell << endl;
            option = 3;
            break;
        case 4:
            string first, second;
            bool good;
            Reversi other;
            int decision;

            do {
                cout << "Suan oynanan bir oyunla baska bir oyunu karsilastirmak isterseniz 1" << endl;
                cout << "Bambaska iki oyunu karsilastirmak isterseniz 2'yi tuslayin" << endl;
                cin>>decision;
            } while (decision != 1 && decision != 2);
            if (decision == 1) {
                cout << "karsilastirmak istediginiz oyunun dosya adini girin" << endl;
                cin>>second;
                other.read(second.c_str());
                good = compare(other);
                if (good == true)
                    cout << "ilk oyun daha iyi ikinci oyundan" << endl;
                else
                    cout << "ikinci oyun daha iyi" << endl;
                option = menuOfGame();
            } else if (decision == 2) {
                cout << "karsilastirmak istediginiz iki oyunun dosya adlarini girin" << endl;
                cin>>first;
                read(first.c_str());
                cin>>second;
                other.read(second.c_str());
                good = compare(other);
                if (good == true)
                    cout << "ilk oyun daha iyi ikinci oyundan" << endl;
                else
                    cout << "ikinci oyun daha iyi" << endl;
                cout << "~~~~Yasayan hucre sayisi=" << Reversi::LivingCell << endl;
                option = menuOfGame();
            }
            break;
    }
    return option;
}

int Reversi::playGame() {

    string sign = "1";
    int count = 0;
    bool end = false;
    Cell user;
    int option = menuOfGame();
    string saveContinueFile;
    while (end == false) {
        if (option == 3 || option == 1 || option == 0) {
            //displayCurrentBoard();
            if (sign == "1") {//user
                cout << (*this);
                play(user);
                sign = "0";
            }
            if (sign == "0") {//computer
                cout << (*this);
                play();
                sign = "1";
            }
            end = endOfGame();
            ++count;
            if (count % 2 == 0) {
                option = playGame();
            }
        }
    }

    return option;
}

void Reversi::pushNewLivingCell(const Cell player, const int row, const int lengths, const int sign) {

    gameCells.at(row).push_back(player);
    ++Reversi::LivingCell;
    sortOfCells_forRow(gameCells.at(row), gameCells.at(row).size());
    for (int i = 0; i < gameCells.size(); ++i) {
        for (int j = 0; j < gameCells.at(i).size(); ++j) {
            if (sign == 6) {
                if ((gameCells.at(i).at(j).getIntX() > player.getIntX() &&
                        gameCells.at(i).at(j).getIntX() <= player.getIntX() + lengths)
                        && player.getY() == gameCells.at(i).at(j).getY())
                    gameCells.at(i).at(j).setPointX_O(player.getPointX_O());


            }
            if (sign == 4) {
                if ((gameCells.at(i).at(j).getIntX() < player.getIntX()
                        && gameCells.at(i).at(j).getIntX() >= player.getIntX() - lengths)
                        && (player.getY() == gameCells.at(i).at(j).getY()))
                    gameCells.at(i).at(j).setPointX_O(player.getPointX_O());
            }
            if (sign == 8) {
                if ((gameCells.at(i).at(j).getY() < player.getY()
                        && gameCells.at(i).at(j).getY() >= player.getY() - lengths)
                        && player.getIntX() == gameCells.at(i).at(j).getIntX())

                    gameCells.at(i).at(j).setPointX_O(player.getPointX_O());
            }
            if (sign == 2) {
                if ((gameCells.at(i).at(j).getY() > player.getY()
                        && gameCells.at(i).at(j).getY() <= player.getY() + lengths)
                        && player.getIntX() == gameCells.at(i).at(j).getIntX())
                    gameCells.at(i).at(j).setPointX_O(player.getPointX_O());
            }
            if (sign == 9) {
                if ((gameCells.at(i).at(j).getIntX() > player.getIntX() &&
                        gameCells.at(i).at(j).getIntX() <= player.getIntX() + lengths))
                    if ((gameCells.at(i).at(j).getY() < player.getY()
                            && gameCells.at(i).at(j).getY() >= player.getY() - lengths))
                        gameCells.at(i).at(j).setPointX_O(player.getPointX_O());


            }
            if (sign == 3) {
                if ((gameCells.at(i).at(j).getIntX() > player.getIntX() &&
                        gameCells.at(i).at(j).getIntX() < player.getIntX() + lengths))
                    if ((gameCells.at(i).at(j).getY() > player.getY()
                            && gameCells.at(i).at(j).getY() < player.getY() + lengths))
                        gameCells.at(i).at(j).setPointX_O(player.getPointX_O());


            }
            if (sign == 1) {
                if ((gameCells.at(i).at(j).getIntX() < player.getIntX()
                        && gameCells.at(i).at(j).getIntX() >= player.getIntX() - lengths))
                    if ((gameCells.at(i).at(j).getY() > player.getY()
                            && gameCells.at(i).at(j).getY() < player.getY() + lengths))
                        gameCells.at(i).at(j).setPointX_O(player.getPointX_O());


            }
            if (sign == 7) {
                if ((gameCells.at(i).at(j).getIntX() < player.getIntX()
                        && gameCells.at(i).at(j).getIntX() >= player.getIntX() - lengths)
                        && (player.getY() == gameCells.at(i).at(j).getY()))
                    if ((gameCells.at(i).at(j).getY() < player.getY()
                            && gameCells.at(i).at(j).getY() >= player.getY() - lengths)
                            && player.getIntX() == gameCells.at(i).at(j).getIntX())

                        gameCells.at(i).at(j).setPointX_O(player.getPointX_O());

            }
        }
    }

}

/*
 * avail fonksiyonuna user yollandiginda oyuncu tarafindan belirlenen nokta yollanir
 * computer yollandiginda uygun noktalar belirlenmek icin her X hucresi yollanir
 */

bool Reversi::available(vector<int>& lengths, const Cell user)const {//fonksiyon hatali bu nedenle yanlis!!!!!!
    int index = 0;
    bool resAvail = true;
    for (int i = 0; i < 11; ++i)
        lengths.at(i) = 0;
    bool sign = false;
    //kendinden sonra eleman var mi diye kontrol et 
    //caprazlarda dikkat et !!!!

    for (int row = 0; row < getRow(); ++row) {
        for (int col = 0; col < getCol(); ++col) {
            for (int i = 0; i < gameCells.size() && sign == false; ++i) {
                for (int j = 0; j < gameCells.at(i).size() && sign == false; ++j) {//saga dogru 6

                    if (gameCells.at(i).at(j).getY() == row && gameCells.at(i).at(j).getIntX() == col) {
                        if (gameCells.at(i).at(j).getY() == user.getY() && gameCells.at(i).at(j).getIntX() > user.getIntX())
                            lengths.at(6) = look(lengths.at(6), user, gameCells.at(i).at(j), sign); //6
                    }
                }
            }

            for (int i = 0; i < gameCells.size() && sign == false; ++i)
                for (int j = gameCells.at(i).size() - 1; j >= 0 && sign == false; --j) {//sola dogru 4
                    if (gameCells.at(i).at(j).getY() == row && gameCells.at(i).at(j).getIntX() == col)
                        if (gameCells.at(i).at(j).getY() == user.getY() && gameCells.at(i).at(j).getIntX() < user.getIntX()) {
                            lengths.at(4) = look(lengths.at(4), user, gameCells.at(i).at(j), sign); //4
                        }
                }


            for (int i = 0; i < gameCells.size() && sign == false; ++i)
                for (int j = 0; j < gameCells.at(i).size() && sign == false; ++j) {//asagi dogru 2
                    if (gameCells.at(i).at(j).getY() == row && gameCells.at(i).at(j).getIntX() == col)
                        if (gameCells.at(i).at(j).getIntX() == user.getIntX() && gameCells.at(i).at(j).getY() > user.getY()) {
                            lengths.at(2) = look(lengths.at(2), user, gameCells.at(i).at(j), sign); //2

                        }
                }

            for (int i = gameCells.size() - 1; i >= 0 && sign == false; --i)
                for (int j = 0; j < gameCells.at(i).size() && sign == false; ++j) {//yukari dogru 8
                    if (gameCells.at(i).at(j).getY() == row && gameCells.at(i).at(j).getIntX() == col)
                        if (gameCells.at(i).at(j).getIntX() == user.getIntX() && gameCells.at(i).at(j).getY() < user.getY()) {
                            lengths.at(8) = look(lengths.at(8), user, gameCells.at(i).at(j), sign); //8

                        }
                }

            for (int i = 0; i < gameCells.size() && sign == false; ++i)
                for (int j = 0; j < gameCells.at(i).size() && sign == false; ++j)//sag alt 3
                    if (gameCells.at(i).at(j).getY() == row && gameCells.at(i).at(j).getIntX() == col)
                        if (gameCells.at(i).at(j).getIntX() > user.getIntX()
                                && gameCells.at(i).at(j).getY() > user.getY()) {
                            if (i + 1 < gameCells.size()) {//bir alt satirin varligi
                                if (j + 1 < gameCells.at(i + 1).size())
                                    lengths.at(3) = look(lengths.at(3), user, gameCells.at(i).at(j), sign); //3
                            }
                        }

            for (int i = gameCells.size() - 1; i >= 0 && sign == false; --i)
                for (int j = 0; j < gameCells.at(i).size() && sign == false; ++j)//sag ust 9
                    if (gameCells.at(i).at(j).getY() == row && gameCells.at(i).at(j).getIntX() == col)
                        if (gameCells.at(i).at(j).getIntX() > user.getIntX() && gameCells.at(i).at(j).getY() < user.getY()) {
                            if (i - 1 >= 0) {
                                if (j + 1 < gameCells.at(i - 1).size())
                                    lengths.at(9) = look(lengths.at(9), user, gameCells.at(i).at(j), sign); //9
                            }

                        }

            for (int i = 0; i < gameCells.size(); ++i)
                for (int j = gameCells.at(i).size() - 1; j >= 0 && sign == false; --j)//sol alt 1
                    if (gameCells.at(i).at(j).getY() == row && gameCells.at(i).at(j).getIntX() == col)
                        if (gameCells.at(i).at(j).getIntX() < user.getIntX() && gameCells.at(i).at(j).getY() > user.getY()) {
                            if (i + 1 < gameCells.size()) {
                                if (j - 1 >= 0 && gameCells.at(i - 1).size() >= 0)
                                    lengths.at(1) = look(lengths.at(1), user, gameCells.at(i).at(j), sign); //1
                            }
                        }

            for (int i = gameCells.size() - 1; i >= 0; --i) {
                for (int j = gameCells.at(i).size() - 1; j >= 0 && sign == false; --j) {//sol ust 7
                    if (gameCells.at(i).at(j).getY() == row && gameCells.at(i).at(j).getIntX() == col)
                        if (gameCells.at(i).at(j).getIntX() < user.getIntX() && gameCells.at(i).at(j).getY() < user.getY()) {
                            if (i - 1 >= 0) {
                                if (j - 1 >= 0 && gameCells.at(i - 1).size() >= 0)
                                    lengths.at(7) = look(lengths.at(7), user, gameCells.at(i).at(j), sign); //7
                            }
                        }
                }
            }
        }
    }
    if (user.getPointX_O() == "O") {
        for (int i = 0; i < gameCells.size(); ++i) {
            //user dolu olan noktalardan birini yolladiysa
            for (int j = 0; j < gameCells.at(i).size(); ++j) {
                if ((user.getIntX() == gameCells.at(i).at(j).getIntX()
                        && user.getY() == gameCells.at(i).at(j).getY())
                        /*|| user.getPointX_O() == "X"*/)
                    resAvail = false;
            }
        }
    }
    index = FindMaxNum_InVector(lengths, 11);
    if (index == 10)
        resAvail = false;

    return resAvail;
}





//eger oyuncu user ise yollanan vector elemaninin X olmasi durumunda uzunluk arttiriliyor
//kendisi olursa olusan length'i donduruyor
//eger oyuncu computer ise yollanan elemanin O olmasi durumnda uzunluk arttiriliyor
//kendisi olursa length 0 yapilip return ediliyor

int Reversi::look(int lengths, const Cell player_, const Cell elementOfVector, bool& sign) const {

    if (player_.getPointX_O() == "O") {
        if (elementOfVector.getPointX_O() == "X") //X
            ++lengths;
        else if (elementOfVector.getPointX_O() == player_.getPointX_O()) {
            return lengths;
            sign = true;
        }
    } else if (player_.getPointX_O() == "X") {
        if (elementOfVector.getPointX_O() == "O") //X
            ++lengths;
        else if (elementOfVector.getPointX_O() == player_.getPointX_O()) {
            lengths = 0;
            return lengths;
        }
    }
    return lengths;
}

//sadece tüm hucrelerin dolma durumunu kontrol ediyor

bool Reversi::endOfGame() {
    for (int i = 0; i < gameCells.size(); ++i) {
        for (int j = 0; j < gameCells.at(i).size(); ++j) {
            if ((getRow() * getCol()) == (gameCells.size() * gameCells.at(i).size()))
                return true;
        }
    }

    return false;
}
//ilk oyun daha iyiyse true doner
//oyunlarin user'larinin isaretlerinin sayisini bulup row*coloum'a boluyoruz
//double cast etme sebebim oranin integer bolmesiyle yanlis sonuc verebilecek olmasi

bool Reversi::compare(const Reversi other)const {
    int countFirst_O = 0;
    int countSecond_O = 0;
    for (int i = 0; i < gameCells.size(); ++i) {
        for (int j = 0; j < gameCells.at(i).size(); ++j) {
            if (gameCells.at(i).at(j).getPointX_O() == "O")
                ++countFirst_O;
        }
    }
    for (int i = 0; i < other.gameCells.size(); ++i) {
        for (int j = 0; j < other.gameCells.at(i).size(); ++j) {
            if (other.gameCells.at(i).at(j).getPointX_O() == "O")
                ++countSecond_O;
        }
    }
    if (static_cast<double> (countFirst_O) / (getCol() * getRow())
            >= static_cast<double> (countSecond_O) / (getCol() * getRow()))
        return true;
    else return false;

}




