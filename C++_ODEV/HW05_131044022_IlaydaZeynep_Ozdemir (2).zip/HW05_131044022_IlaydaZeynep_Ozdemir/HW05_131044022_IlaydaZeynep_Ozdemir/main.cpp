/* 
 * File:   main.cpp
 * Author: ilayda Zeynep Ozdemir 131044022
 *
 * Created on November 18, 2015, 2:08 AM
 */

#include <iostream>

#include "Reversi.h"

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    cout << "Reversi testleri~~~~" << endl;
    Reversi R_test1;
    Reversi R_test2(8, 8);
    Reversi R_test3(4, 8);
    Reversi R_test4(5, 5);
    Reversi R_test5(10, 10);
    
    cout << "-------------------------1---------------------------------" << endl;
    R_test1.testForReversi();
    cout << "-------------------------2---------------------------------" << endl;
    R_test2.testForReversi();
    cout << "-------------------------3---------------------------------" << endl;
    R_test3.testForReversi();
    cout << "-------------------------4---------------------------------" << endl;
    R_test4.testForReversi();
    cout << "-------------------------5---------------------------------" << endl;
    R_test5.testForReversi();
    cout << "----------------------------------------------------------" << endl;

    cout << "Cell testleri~~~~" << endl;//Cell testlerini ayri yapma sebebim 
    //Reversi oyunum tam olarak dogru degil bu nedenle saglikli sonuclar vermiyor
    Cell test1(5, "a"), test2(5, "b"), test4(4, "a"), test5(4, "a");
    test1.testForOperators(test2);
    test1.testForOperators(test4);
    test4.testForOperators(test5);
    



    return 0;
}

