/* 
 * File:   Cell.cpp
 * Author: ilayda Zeynep Ozdemir 131044022
 * 
 * Created on November 23, 2015, 12:12 PM
 */

#include "Cell.h"
#include <string>
#include <iostream>
#include <cstdlib>
using namespace std;


//getC

Cell::Cell() {
    setX("a");
    setY(0);
    setPointX_O("O");
}

Cell::Cell(int pos_Y, string pos_X) {
    setY(pos_Y);
    setX(pos_X);
    setPointX_O("O");
}

Cell::Cell(int pos_Y, string pos_X, string what) {
    setX(pos_X);
    setY(pos_Y);

    setPointX_O(what);
}

void Cell::setX(const string position) {
    m_X = position; //coloum
    setIntX();
}

void Cell::setY(const int position) {
    m_Y = position; //row
}

void Cell::setIntX() {
    string forIntPart;
    string intPart;
    int temp;
    int valueOfletter;


    for (int i = 0; i < getX().length(); ++i) {

        for (int j = 0; j < 23; ++j) {
            if (getX().at(i) == letterss[j].at(0)) {

                temp = j;
                for (int k = i; k < getX().size(); ++k) {
                    forIntPart += getX().at(k);
                }
            }
        }
    }

    valueOfletter = temp + atoi(forIntPart.c_str());
    for (int i = 1; i < m_X.length(); ++i) {//0.elemani int degil char
        //bu nedenle birden baslattim
        intPart += m_X[i];
    }
    int value_of_intX = atoi(intPart.c_str());
    m_IntX = (value_of_intX * 23) + valueOfletter;
    //burada yaptigim sey : a25 in integer oalrak degerini bulmak
    //25 * 23(harf arrayinin sayisi) + 1(a'nin degeri)
    if (getX() == "w")
        m_IntX = -1000;


}
// tablo elemanlari

void Cell::setPointX_O(const string what_char) {
    m_PointX_O = what_char;
}

istream& operator>>(istream& input, Cell& takenCell) { //extraction
    string tempX;
    int tempY;
    string tempXO;
    input >> tempY >> tempX>>tempXO;
    takenCell.setY(tempY);
    takenCell.setX(tempX);
    takenCell.setPointX_O(tempXO);
    return input;
}

ostream& operator<<(ostream& output, const Cell givenCell) { //insertion
    output << givenCell.getY()<<"-" << givenCell.getX() <<"-"<< givenCell.getPointX_O();
    return output;
}

bool Cell::operator>(const Cell& right)const {
    if (getY() > right.getY())
        return true;
    else if (getY() < right.getY())
        return false;
    else if (getY() == right.getY()) {
        if (getX() > right.getX())
            return true;
        else if ((getX() < right.getX()) || (getX() == right.getX()))
            return false;
    }
}

bool Cell::operator<(const Cell& right)const {
    if (getY() < right.getY())
        return true;
    else if (getY() > right.getY())
        return false;
    else if (getY() == right.getY()) {
        if (getX() > right.getX())
            return false;
        else if ((getX() < right.getX()) || (getX() == right.getX()))
            return true;
    }
}

bool Cell::operator>=(const Cell& right)const {
    if ((*this) > right)
        return true;
    else if ((*this) == right)
        return true;
    else if ((*this) < right)
        return false;
}

bool Cell::operator<=(const Cell& right)const {
    if ((*this) >= right)
        return false;
    else return true;
}

bool Cell::operator==(const Cell& right)const {
    if (getX() == right.getX() && getY() == right.getY()
            && getPointX_O() == right.getPointX_O())
        return true;
    else return false;
}

bool Cell::operator!=(const Cell& right)const {
    if ((*this) == right)
        return false;
    else return true;

}

void Cell::testForOperators(const Cell& other) {
    cout<<"||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||"<<endl;
    if ((*this) == other)
        cout << "Cell objesi(" << (*this) << ") == diger Cell'e(" << other << ")" << endl;
    if ((*this) >= other)
        cout << "Cell objesi(" << (*this) << ") >= diger Cell'e(" << other << ")" << endl;
    if ((*this) <= other)
        cout << "Cell objesi(" << (*this) << ") <= diger Cell'e(" << other << ")" << endl;
    if ((*this) > other)
        cout << "Cell objesi(" << (*this) << ") > diger Cell'e(" << other << ")" << endl;
    if ((*this) < other)
        cout << "Cell objesi(" << (*this) << ") < diger Cell'e(" << other << ")" << endl;
    if ((*this) != other)
        cout << "Cell objesi(" << (*this) << ") != diger Cell'e(" << other << ")" << endl;
    cout<<"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"<<endl;
    cout<<(++(*this))<<"~Arttirdigi degeri dondurur"<<endl<<endl;
    cout<<((*this)++)<<"~Arttirilmamis degeri dondurur.Arttirilmis hali: ";
    cout<<(*this)<<endl<<endl;
    cout<<(--(*this))<<"~Azaltilmis degeri dondurur"<<endl<<endl;
    cout<<((*this)--)<<"~Azaltilmamis degeri dondurur.";
    cout<<"Azaltilmis hali: "<<(*this)<<endl<<endl;
    cout<<"||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||"<<endl;
}

Cell Cell::operator++() { //pre ++cell Y lerini arttiriyorum
    ++(this->m_Y);
    return (*this);
}

Cell Cell::operator++(int x) { //post cell++
    Cell temp;
    temp.setX((*this).getX());
    temp.setY((*this).getY());
    temp.setPointX_O((*this).getPointX_O());
    ++(this->m_Y);
    return temp;

}

Cell Cell::operator--() { //pre --cell
    --(this->m_Y);
    return (*this);
}

Cell Cell::operator--(int x) { //post cell--
    Cell temp;
    temp.setX((*this).getX());
    temp.setY((*this).getY());

    temp.setPointX_O((*this).getPointX_O());
    --(this->m_Y);
    return temp;

}







