/* 
 * File:   Reversi.h
 * Author: ilayda Zeynep Ozdemir 131044022
 *
 * Created on November 23, 2015, 12:07 PM
 */

#ifndef REVERSI_H
#define	REVERSI_H

#include "Cell.h"
#include <vector>
#include <fstream>

class Reversi {
public:



    Reversi();
    Reversi(int Coloum_and_Row);
    Reversi(int Coloum, int Row);
    //void displayCurrentBoard();

    void play(); //computer oynuyor
    void play(Cell& user); //user oynuyor
    int playGame();
    static int getLivingCell();
    bool compare(const Reversi other)const;
    int getCol()const;
    int getRow()const;
    void read(const char* inputFile);
    void write(const char* outputFile)const;
    void setSizesTable(const int row, const int col);
    static int getLivingCells();
    Reversi operator++(); //pre bir adim sonrasi 
    Reversi operator++(int x); //post o anki adim return edilir ama adim bir ileri alinir
    Reversi operator--(); //pre
    Reversi operator--(int x);//post
    //l-value r value olanlari farkli unutma
    Cell& operator[](std::string position);
    Cell& operator()(int Y, std::string X);
    Reversi operator+=( Cell forUser);
    friend std::ostream& operator<<(std::ostream& outgame, const Reversi game);

    void setStartVector();
    void testForReversi();


private:
    bool endOfGame();
    std::string myItoa(int IntNum)const;
    int FindMaxNum_InVector(const std::vector<int>& vector_, int size)const;
    void sortOfCells_forRow(std::vector<Cell>& RowVector, int currentSizeCol);
    void SwapCells(Cell& Cell1, Cell& Cell2);
    bool available(std::vector<int>& lengths, const Cell player_)const;
    int look(int lengths, const Cell player_, const Cell elementOfVector, bool& sign)const;
    void pushNewLivingCell(const Cell player, const int row, const int lengths, const int sign);
    void convertFormat(int length, int side);
    int menuOfGame();
    /*static const std::string USER_SYMBOL()const {
        return "O";
     }

    static const std::string COMPUTER_SYMBOL()const {
        return "X";
    }*/

    static int LivingCell; //kac tane Reversi cagirilirsa cagirilsin bir tane olusur
    Cell computer;
    std::vector< std::vector<Cell> > gameCells;
    int sizeOfCol; //width
    int sizeOfRow; //height

    void setRow(const int row) {
        sizeOfRow = row;
    }

    void setCol(const int col) {
        sizeOfCol = col;
    }

};

#endif	/* REVERSI_H */

