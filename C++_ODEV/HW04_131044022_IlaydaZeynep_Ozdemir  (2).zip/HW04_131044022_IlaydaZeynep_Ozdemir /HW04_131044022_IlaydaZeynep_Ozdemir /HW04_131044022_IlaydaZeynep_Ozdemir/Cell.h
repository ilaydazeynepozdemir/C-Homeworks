/* 
 * File:   Cell.h
 * Author: ilayda zeynep ozdemir 13104402
 *
 * Created on November 6, 2015, 7:49 PM
 */

#ifndef CELL_H
#define	CELL_H

#include <string>

class Cell {
public:
    Cell();
    Cell(int pos_Y, std::string pos_X, std::string what); //what X mi O mu anlamak icin 
    void setX(const std::string position);
    void setY(const int position);
    void setPointX_O(const std::string what_char);
    void setIntX(const int startLetter);
    
    inline int getIntX()const {
        return m_IntX;
    };

    std::string getX()const {
        return m_X;
    };

    int getY()const {
        return m_Y;
    };

    std::string getPointX_O()const {
        return m_PointX_O;
    };

private:
    //m_X X koordinatlarini tutan bir char ama 23ten 
    //buyuk oldugunda a1,b1...a8,b8.. gibi stringler alacagi icin char yerine string olarak tuttum
    std::string m_X;
    int m_Y;
    int m_IntX; //X'in integera cevirilmis hali
    std::string m_PointX_O;//ekrana basilan tablo m_PointX_O memberinda

};


const std::string letterss[23] = {"a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "r", "s", "t", "u", "v", "y", "z"};

#endif	/* CELL_H */

