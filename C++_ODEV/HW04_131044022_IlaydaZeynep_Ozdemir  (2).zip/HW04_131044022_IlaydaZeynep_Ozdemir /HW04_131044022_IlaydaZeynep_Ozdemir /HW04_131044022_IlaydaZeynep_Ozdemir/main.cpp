/* 
 * File:   main.cpp
 * Author: ilayda zeynep ozdemir 131044022
 *
 * Created on November 6, 2015, 7:45 PM
 */

#include <iostream>
#include "Reversi.h"

using namespace std;

/*
 * 
 */

int main(int argc, char** argv) {
    Reversi Reversi1(4, 4);
    Reversi1.playGame();
    Reversi Reversi2(8,8);
    Reversi2.playGame();
    Reversi Reversi3(10, 10);
    Reversi3.playGame();
    Reversi Reversi4(10, 10);
    Reversi4.playGame();
    Reversi Reversi5(10, 10);
    Reversi5.playGame();
    return 0;
}
