/* 
 * File:   Cell.cpp
 * Author: ilayda zeynep ozdemir 13104402
 * 
 * Created on November 6, 2015, 7:49 PM
 */

#include "Cell.h"
#include <string>
#include <cstdlib>
using namespace std;

Cell::Cell() {
    setX("a");
    setIntX(0);
    setY(0);
}

Cell::Cell(int pos_Y, string pos_X, string what) {
    setX(pos_X);
    setY(pos_Y);
    setPointX_O(what);
}

void Cell::setX(const string position) {
    m_X = position; //coloum
}

void Cell::setY(const int position) {
    m_Y = position; //row
}

void Cell::setIntX(const int valueOfletter) {
    string intPart;
    for(int i=1;i<m_X.length();++i){//0.elemani int degil char
                                    //bu nedenle birden baslattim
        intPart += m_X[i];
    }
    int value_of_intX = atoi(intPart.c_str());
    m_IntX = (value_of_intX*23)+valueOfletter;
    //burada yaptigim sey : a25 in integer oalrak degerini bulmak
    //25 * 23(harf arrayinin sayisi) + 1(a'nin degeri)  
}

// tablo elemanlari
void Cell::setPointX_O(const string what_char) {
    m_PointX_O = what_char;
}



