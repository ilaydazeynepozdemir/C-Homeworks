/* 
 * File:   main.cpp
 * Author: Ilayda Zeynep Ozdemir
 *
 * Created on October 17, 2015, 7:46 PM
 */
#include <iostream>
#include <string.h>
using namespace std;

class DayOfYear {
public:
    int day;
    int month;
};

class Person {
public:
    char name[10];
    char surname[10];
    int age;
};

//return_mode arrayi kendisine yollanan arrayin en cok tekrarlanan elemanini bulup
//indexini return eder
int return_mode(const void * base, size_t num, size_t size,
        bool (* equals)(const void *, const void *));
bool equals_int(const void *eql1, const void *eql2);
bool equals_double(const void *eql1, const void *eql2);
bool equals_char(const void *eql1, const void *eql2);
bool equals_Person(const void *eql1, const void *eql2);
bool equals_DayOfYear(const void *eql1, const void *eql2);

const int NUM = 10;

int main(int argc, char** argv) {
    
    //////Test edilmek icin hazirlanan arrayler//////
    int int_base[NUM] = {3, 2, 5, 1, 6, 1, 1, 2, 5, 21};
    int int_base2[NUM] = {0, 100, 0, 1, 100, 100, 120, 200, 500, 210};
    
    double double_base[NUM] = {0.2, 0.3, 1.0, 5.1, 0.2, 12.5, 12.5, 7.2, 12.5, 7.2};
    double double_base2[NUM] = {12.7, 100.5, 182.2, 182.5, 182.2, 12.7, 12.5, 182.2, 12.5, 7.2};
    
    char char_base[NUM] = {'a', 'c', 'a', 'd', 'c', 'c', 'd', 'h', 'a', 'a'};
    char char_base2[NUM] = {'j', 'i', '*', '*', '%', '%', '+', '+', '+', 'a'};
    
    DayOfYear Day_base[NUM] = {9, 8, 1, 2, 4, 5, 4, 5, 4, 5, 1, 2, 1, 2, 10, 11, 10, 11, 12, 5};
    DayOfYear Day_base2[NUM] = {20, 7, 20, 7, 20, 5, 20, 8, 18, 5, 18, 2, 16, 2, 19, 12, 1, 11, 20, 7};
    
    Person Person_base[NUM] = {"Ali", "Asrin", 17, "Ali", "Asrin", 10, "Ali", "Asrin", 10,
        "Zeynep", "Tok", 18, "Doruk", "Yalcin", 25, "Yalin", "Yalcin", 28,
        "Doruk", "Yalcin", 25, "Yalin", "Yalcin", 28, "Doruk", "Yalcin", 25, "Doruk", "Yalcin", 28,};
    Person Person_base2[NUM] = {"Kubra", "Gungor", 18, "Kubra", "Erturac", 20, "Ilayda", "Ozdemir", 20,
        "Zeynep", "Ozdemir", 18, "Hazal", "Gonen", 20, "Doruk", "Yalcin", 28,
        "Doruk", "Yalcin", 25, "Yalin", "Yalcin", 28, "Kubra", "Gungor", 25, "Doruk", "Yalcin", 28,};
    
    /////////////////////////////////////////////

    cout << "INTEGER" << endl;
    int mod_int = return_mode(int_base, NUM, sizeof (int), equals_int);
    cout << "int_base arrayinin modunun indexi = " << mod_int << endl;
    int mod_int2 = return_mode(int_base2, NUM, sizeof (int), equals_int);
    cout << "int_base2 arrayinin modunun indexi = " << mod_int2 << endl<<endl;

    cout << "DOUBLE" << endl;
    int mod_double = return_mode(double_base, NUM, sizeof (double), equals_double);
    cout << "double_base arrayinin modunun indexi = " << mod_double << endl;
    int mod_double2 = return_mode(double_base2, NUM, sizeof (double), equals_double);
    cout << "double_base2 arrayinin modunun indexi = " << mod_double2 << endl<<endl;

    cout << "CHAR" << endl;
    int mod_char = return_mode(char_base, NUM, sizeof (char), equals_char);
    cout << "char_base arrayinin modunun indexi = " << mod_char << endl;
    int mod_char2 = return_mode(char_base2, NUM, sizeof (char), equals_char);
    cout << "char_base2 arrayinin modunun indexi = " << mod_char2 << endl<<endl;

    cout << "DAYOFYEAR" << endl;
    int mod_Day = return_mode(Day_base, NUM, sizeof (DayOfYear), equals_DayOfYear);
    cout << "Day_base arrayinin modunun indexi = " << mod_Day << endl;
    int mod_Day2 = return_mode(Day_base2, NUM, sizeof (DayOfYear), equals_DayOfYear);
    cout << "Day_base2 arrayinin modunun indexi = " << mod_Day2 << endl<<endl;

    cout << "PERSON" << endl;
    int mod_Person = return_mode(Person_base, NUM, sizeof (Person), equals_Person);
    cout << "Person_base arrayinin modunun indexi = " << mod_Person << endl;
    int mod_Person2 = return_mode(Person_base2, NUM, sizeof (Person), equals_Person);
    cout << "Person_base2 arrayinin modunun indexi = " << mod_Person2 << endl<<endl;


    return 0;
}
///////////////////////////////////////////////////////////////////////////////
//equals fonksiyonlari array elemanlarinin esitlikliklerine karar verir       /
//eger esitlerse true degillerse false dondurur                               /
//int,double,char,DayOfYear,Person olmak uzere bes tip icin yazildi           /
//eger farkli tipler icin return_mode fonksiyonu kullanilacaksa onlar icin de /
//equals fonksiyonu yazilmali                                                 /
///////////////////////////////////////////////////////////////////////////////

bool equals_int(const void *eql1, const void *eql2) {
    int *int_eql1 = (int*) eql1;
    int *int_eql2 = (int*) eql2;
    if (*int_eql1 == *int_eql2)
        return true;
    else return false;

}

bool equals_double(const void *eql1, const void *eql2) {
    double *double_eql1 = (double*) eql1;
    double *double_eql2 = (double*) eql2;
    if (*double_eql1 == *double_eql2) return true;
    else return false;
}

bool equals_char(const void *eql1, const void *eql2) {
    char *char_eql1 = (char*) eql1;
    char *char_eql2 = (char*) eql2;
    if (*char_eql1 == *char_eql2) return true;
    else return false;
}

bool equals_Person(const void *eql1, const void *eql2) {
    Person *P_eql1 = (Person*) eql1;
    Person *P_eql2 = (Person*) eql2;
    if ((strcmp(P_eql1->name, P_eql2->name) == 0) &&
            (strcmp(P_eql1->surname, P_eql2->surname) == 0) &&
            (P_eql1->age == P_eql2->age))
        return true;
    else return false;
}

bool equals_DayOfYear(const void *eql1, const void *eql2) {
    DayOfYear *D_eql1 = (DayOfYear*) eql1,
            *D_eql2 = (DayOfYear*) eql2;
    if ((D_eql1->day == D_eql2->day) && (D_eql1->month == D_eql2->month))
        return true;
    else return false;
}
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//return_mode fonksiyonu ana fonksiyondur                                     /
//mod olan elemanin ilkinin indexini dondurecek fonksiyon.                    /
//eger tum elemanlar esitse ilk elemanin indexini dondurur.                   /
//diyelim ki bir array icinde farkli her elemandan esit sayilarda var.        /
//boyle zamanlarda da ilk indexi dondurur.                                    /
///////////////////////////////////////////////////////////////////////////////

int return_mode(const void * base, size_t num, size_t size,
        bool (* equals)(const void *, const void *)) {
    unsigned char *start;
    unsigned char *start2;
    unsigned char *end = (unsigned char*) base + (size * num);
    unsigned char *end2 = (unsigned char*) base + (size * num);
    int count_arr[num];
    int count = 0;
    int index;
    int i = 0;
    for (start = (unsigned char*) base; start < end; start += size) {
        count = 0;
        for (start2 = (unsigned char*) base; start2 < end2; start2 += size) {
            if (equals(start, start2)) {
                ++count;
                count_arr[i] = count;
            }
        }
        ++i;
    }
    int max = 0;
    for (i = 0; i < num; ++i) {
        if (count_arr[i] > max) {
            max = count_arr[i];
            index = i;
        }
    }
    return index;
}

