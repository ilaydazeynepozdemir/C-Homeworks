/* 
 * File:   Triangle.h
 * Author: Ilayda Zeynep Ozdemir 131044022
 *
 * Created on October 19, 2015, 6:16 PM
 */

#ifndef TRIANGLE_H
#define	TRIANGLE_H

class Triangle {
public:
    //Constructors(0,1,2,3 parametreli)
    Triangle();
    Triangle(double ABC); //eskanar ucgen icin
    Triangle(double A, double B);
    Triangle(double A, double B, double C); //2 , 3 icin
    //kullanicidan ucgen kenarlarini alir
    void input();
    //ucgen kenarlarini ekrana basar
    void output() const;

    //get fonksiyonlari kullanicinin disaridan A,B,C kenarlarina ulasmasini 
    //bunlarla islem yapabilmesini saglar
    double getA() const;
    double getB() const;
    double getC() const;
    //angle fonksiyonlari ucgenin acilarini verir
    double angleA() const;
    double angleB() const;
    double angleC() const;
    bool rightAngle() const; //dik ucgense true
    double areaOfTriangle()const; //ucgenin alanini hesapalar
    double perimeterOfTriangle() const; //cevre uzunlugunu hesaplar
    //tum kenarlari doldurur
    void setAllSides(double side1, double side2, double side3);

private:
    //kontrolsuz setter fonksiyonlari    
    void setA(double side1);
    void setB(double side2);
    void setC(double side3);

    double side_A;
    double side_B;
    double side_C;
};

//benzerlik oranini return eder 
//eger benzerlik yoksa 0 return eder
double similarityRate(Triangle triangle1, Triangle triangle2);
//aldigi iki ucgenin kenarlarini degistirir
void changeTriangleSides(Triangle& triangle_1, Triangle& triangle_2);


#endif	/* TRIANGLE_H */

