/* 
 * File:   main.cpp
 *  Author: Ilayda Zeynep Ozdemir 131044022
 *
 * Created on October 19, 2015, 2:38 AM
 */
#include <iostream>
#include <math.h>
#include "Triangle.h"
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    Triangle Tri1;
    Tri1.output();
    Tri1.input();
    cout << "Alani= " << Tri1.areaOfTriangle() << endl;
    cout << "Cevre Uzunlugu= " << Tri1.perimeterOfTriangle() << endl;
    cout << "Dik ucgen mi? " << Tri1.rightAngle() << endl;
    cout << "A-B-C kenarlarinin acilari~~~" << endl;
    cout << Tri1.angleA() << " - " << Tri1.angleB() << " - " << Tri1.angleC() << endl << endl << endl;

    Triangle Tri2(1.0, sqrt(2));
    Tri2.output();
    cout << "Alani= " << Tri2.areaOfTriangle() << endl;
    cout << "Cevre Uzunlugu= " << Tri2.perimeterOfTriangle() << endl;
    cout << "Dik ucgen mi? " << Tri2.rightAngle() << endl;
    cout << "A-B-C kenarlarinin acilari~~~" << endl;
    cout << Tri2.angleA() << " - " << Tri2.angleB() << " - " << Tri2.angleC() << endl << endl << endl;

    Triangle Tri3(4, 3, 5), Tri4(3, 5, 4);
    double test_1 = similarityRate(Tri3, Tri4);
    if (test_1 != 0.0) {
        cout << "Bu iki ucgenin aralarindaki benzerlik orani= "
                << test_1 << endl;
    } else {
        cout << "Bu iki ucgen arasinda benzerlik yok!" << endl;
    }
    cout << endl << endl;

    Triangle Tri5(sqrt(2) - 1, sqrt(4 - (2 * sqrt(2))));
    Triangle Tri6(4);
    
    cout<<"Tri5 ucgeninin kenarlari "<<endl;
    Tri5.output();
    cout<<"Tri6 ucgeninin kenarlari "<<endl;
    Tri6.output();
    cout<<endl;
    
    changeTriangleSides(Tri5, Tri6);//aldigi iki ucgenin kenarlarini degistiriyor
    
    cout << "Tri5 ucgeninin yeni kenarlari" << endl;
    Tri5.output();
    cout << "Tri6 ucgeninin yeni kenarlari" << endl;
    Tri6.output();
    return 0;
}

