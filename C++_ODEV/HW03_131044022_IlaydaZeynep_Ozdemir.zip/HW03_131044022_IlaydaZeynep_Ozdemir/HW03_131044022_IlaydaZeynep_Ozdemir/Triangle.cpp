/* 
 * File:   Triangle.cpp
 * Author: Ilayda Zeynep Ozdemir 131044022
 * 
 * Created on October 19, 2015, 6:16 PM
 */

#include "Triangle.h"
#include <iostream>
#include <math.h>
#include <string>
#include <cstdlib>
using namespace std;

double const PI = 3.14159265;

////Constructors(0,1,2,3 parametreli)

Triangle::Triangle() {
    setAllSides(1.0, 1.0, 1.0);
}

//eskenar ucgen
Triangle::Triangle(double ABC) {
    setAllSides(ABC, ABC, ABC);
}

Triangle::Triangle(double A, double B) {
    setAllSides(A, B, 1.0);
}

Triangle::Triangle(double A, double B, double C) {
    setAllSides(A, B, C);
}
///
//Set fonksiyonu
//tum parametreleri tek bir set fonksiyonu ile doldurdum

void Triangle::setAllSides(double side1, double side2, double side3) {
    if (side1 > fabs(side2 - side3) && side1 < (side2 + side3)) {
        setA(side1);
        if (side2 > fabs(side1 - side3) && side2 < (side1 + side3)) {
            setB(side2);
            if (side3 > fabs(side2 - side1) && side1 < (side2 + side1))
                setC(side3);
        }
    } else {
        cerr << side1 << "-" << side2 << "-" << side3 << " ucgen olusturmuyor." << endl;
        exit(1);
    }

}

//tek tek set eden fonksiyonlar
//bunlari private yapmamin amaci kullanici bu fonksiyonlara ulasip degistirmek 
//isterse ucgen olmayan bir ucgen elde etmeye calisabilir
// bu da hatali sonuclar dogurur
void Triangle::setA(double side1) {
    side_A = side1;
}

void Triangle::setB(double side2) {
    side_B = side2;
}

void Triangle::setC(double side3) {
    side_C = side3;
}

//kullanicidan ucgen kenarlarini alir
void Triangle::input() {
    //string olarak almamin sebebi kullanicinin yanlislikla girdigi 
    //sayi disi bir karakteri isleme sokmamak icin
    char s_A[20], s_B[20], s_C[20];
    cout << "ucgen kenar uzunluklarini girin" << endl;
    cin >> s_A >> s_B>> s_C;

    setAllSides(atof(s_A), atof(s_B), atof(s_C));
}

//get fonksiyonlari kullaniciya disaridan kenarlara ulasma imkani verir

double Triangle::getA() const {
    return side_A;
}

double Triangle::getB() const {
    return side_B;
}

double Triangle::getC() const {
    return side_C;
}

//ucgen kenarlarini ekrana basar
void Triangle::output() const {
    cout.setf(ios::fixed);
    cout.setf(ios::showpoint);
    cout.precision(1);
    cout << "~A kenari " << getA() << " ~B kenari " << getB() << " ~C kenari " << getC() << endl;
}

//angle fonksiyonlari kenarlarin acilarini hesaplar
//angle fonksiyonlarinin return degerlerini if icinde 
//kullanirken int'e cast edilmesi gerekir

double Triangle::angleA() const {
    return ( (180.0 / PI) * acos((pow(getB(), 2.0) + pow(getC(), 2.0) - pow(getA(), 2.0)) / (2.0 * getB() * getC())));
}

double Triangle::angleB() const {
    return ( (180.0 / PI) * acos((pow(getA(), 2.0) + pow(getC(), 2.0) - pow(getB(), 2.0)) / (2.0 * getA() * getC())));
}

double Triangle::angleC() const {
    return ((180.0 / PI) * acos((pow(getB(), 2.0) + pow(getA(), 2.0) - pow(getC(), 2.0)) / (2.0 * getB() * getA())));
}
/////////////////////////////////////////////////////

//dik ucgense true(1) degilse false(0) dondurur
bool Triangle::rightAngle() const {
    bool res = false;
    //fonksiyonun return degerini if icinde kullanmak icin
    //int bir degiskene atiyarak int kismini alip if koşulunda 
    //kullandim
    int AngleA = angleA(), AngleB = angleB(), AngleC = angleC();
    if (AngleA == 90 || AngleB == 90 || AngleC == 90)
        res = true;
    return res;
}

//ucgenin cevre uzunlugunu verir
double Triangle::perimeterOfTriangle() const {
    return getA() + getB() + getC();
}

//ucgenin alanini hesaplar
double Triangle::areaOfTriangle() const {
    return ( (1.0 / 2.0) * getB() * getC() * sin(angleA()*(PI / 180.0)));
}

//call by value
//ucgenin kenar degerleri degismez!
//Bu fonksiyon aldigi iki ucgen arasinda benzerlik var mi diye bakar 
//varsa benzerlik oranini return eder
//yoksa 0 return eder
double similarityRate(Triangle triangle1, Triangle triangle2) {
    bool similarity = false;
    double rate = 0.0; //oran

    cout << "birinci ucgen kenarlari" << endl;
    triangle1.output();
    cout << "ikinci ucgen kenarlari" << endl;
    triangle2.output();
    if (triangle1.angleA() == triangle2.angleA() &&
            triangle1.angleB() == triangle2.angleB() &&
            triangle1.angleC() == triangle2.angleC())
        similarity = true;
    else if (triangle1.angleA() == triangle2.angleA() &&
            triangle1.angleB() == triangle2.angleC() &&
            triangle1.angleC() == triangle2.angleB())
        similarity = true;
    else if (triangle1.angleA() == triangle2.angleB() &&
            triangle1.angleB() == triangle2.angleA() &&
            triangle1.angleC() == triangle2.angleC())
        similarity = true;
    else if (triangle1.angleA() == triangle2.angleB() &&
            triangle1.angleB() == triangle2.angleC() &&
            triangle1.angleC() == triangle2.angleA())
        similarity = true;
    else if (triangle1.angleA() == triangle2.angleC() &&
            triangle1.angleB() == triangle2.angleA() &&
            triangle1.angleC() == triangle2.angleB())
        similarity = true;
    else if (triangle1.angleA() == triangle2.angleC() &&
            triangle1.angleB() == triangle2.angleB() &&
            triangle1.angleC() == triangle2.angleA())
        similarity = true;

    //benzerlik orani alanlarinin oraninin kare koku veya 
    //cevrelerinin birbirine orani
    if (similarity == true)
        rate = sqrt(triangle1.areaOfTriangle() / triangle2.areaOfTriangle());
    else
        rate = 0.0;

    return rate;
}

//call by reference
//ucgenin kenar degerleri degisir ve reference olarak alindigi icin
//geri yeni degerlerin adresleri doner
//bu fonksiyon aldigi ucgenlerin kenarlarinin yerlerini degistirir ve dondurur
void changeTriangleSides(Triangle& triangle_1, Triangle& triangle_2) {
    double keepA = triangle_1.getA();
    double keepB = triangle_1.getB();
    double keepC = triangle_1.getC();
    triangle_1.setAllSides(triangle_2.getA(), triangle_2.getB(), triangle_2.getC());
    triangle_2.setAllSides(keepA, keepB, keepC);   
}
