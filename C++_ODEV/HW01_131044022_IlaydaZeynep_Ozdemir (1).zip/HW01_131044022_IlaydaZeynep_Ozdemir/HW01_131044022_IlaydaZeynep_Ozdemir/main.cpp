/* 
 * File:   main.cpp
 * Author: ilayda zeynep ozdemir
 *
 * Created on September 18, 2015, 6:06 PM by ilayda zeynep ozdemir
 */

#include <iostream>
#include <cstdlib>

using namespace std;

struct avail_loc {
    int length0, length1, length2, length3, length4, length5, length6, length7,
    length8;
    int sign_0, sign_1, sign_2, sign_3, sign_4, sign_5, sign_6, sign_7, sign_8;

};

struct player {
    int int_row;
    int int_col;
    bool turn;
    avail_loc avl_location;

};

struct score_win_lose {
    int computer_score;
    int player_score;
    bool win_or_lose;

};

//oyun row ve coloumini belirler
void decide_row_coloum(int *row, int *coloum, char table[21][22],
        char number_1[20], char number_2[20]);

//oyun tablosunu basar
void print_table_of_game(int row, int coloum, char table[21][22]);

//baslangic tablosunu olusturur
void start_table(int row, int coloum, char table[21][22],
        char letters[20], char number_1[20], char number_2[20], int turn);

//oynanacak konumlari kullanicidan alir
player decide_location(int row, int coloum, char table[21][22],
        player player_, char letters[20], char number_1[20], char number_2[20]);
//ortak fonksiyon
//X O sayilarini bulur 
// hic bosluk kalmadiginda oyun bitirecek degiskeni aktiflestirir
score_win_lose calculate_score(int row, int coloum, char table[21][22]);

//ortak fonksiyon
//oynanacak konumun bos-dolulugunu kontrol eder
//bossa 1,doluysa 0
bool empty_full(int row, int coloum, char table[21][22], player player_);

//ortak fonksiyon
//konumun etrafina bakar uygun yerleri donusturmek icin uzunluklari belirler
avail_loc available(int row, int coloum, char table[21][22],
        player player_, char P1, char P2);

//oyuncunun fonksiyonlarini icerir
//recursive
player play_player(int row, int coloum, char table[21][22],
        player player_, char letters[20], char number_1[20],
        char number_2[20]);

//ortak fonksiyon
//available fonksiyonu ile ortak calisir
player control_table(int row, int coloum, char table[21][22],
        player player_, char P1, char P2);
//bilgisayarin oyun fonksiyonlarini icerir
player play_comp(int row, int coloum, char table[21][22],
        player player_X);
//bilgisayarin kararini verir
player logical_decision(int row, int coloum, char table[21][22],
        player player_X);
player find_max_length(int row, int coloum, char table[21][22],
        player player_X, int i, int j);

//bool find_whose_turn(player player_, char P1, bool turn);

//kazanip-kaybeden taraflari ekrana bastirir
//oyuncu ve bilgisayar isaret sayilarini ekrana bastirir
void information_win_lose(score_win_lose win_lose);

//############################## MAIN ##############################//

int main(int argc, char** argv) {
    int row, coloum;
    int sign = 0;
    char table[21][22];
    int i, j;
    int turn = 1; //0 bilgisayar;1 oyuncu
    score_win_lose score_w_l;

    player player_O, player_X;
    char letters[20] = {'a', 'b', 'c', 'd', 'e', 'f', 'g',
        'h', 'i', 'j', 'k', 'l', 'm', 'n',
        'o', 'p', 'r', 's', 't', 'u',};
    char number_1[20] = {'1', '2', '3', '4', '5', '6', '7', '8', '9',
        '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '2'};
    char number_2[20] = {' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0'};

    for (i = 0; i < 21; ++i) {
        for (j = 0; j < 22; ++j) {
            table[i][j] = '.';
        }
    }

    srand(time(NULL));
    if (rand() % 2 == 0 || rand() % 5 == 0 || rand() % 7 == 0)
        turn = 0;

    decide_row_coloum(&row, &coloum, table, number_1, number_2);
    start_table(row, coloum, table, letters, number_1, number_2, turn);
    print_table_of_game(row, coloum, table);

    while (score_w_l.win_or_lose == 0) {
        if (turn == 1 && score_w_l.win_or_lose == 0) {
            turn = 0;

            player_O = decide_location(row, coloum, table, player_O, letters,
                    number_1, number_2);
            player_O = play_player(row, coloum, table, player_O, letters,
                    number_1, number_2);

            print_table_of_game(row, coloum, table);


        }

        if (turn == 0 && score_w_l.win_or_lose == 0) {
            turn = 1;
            cout << endl << endl;
            player_X = play_comp(row, coloum, table, player_X);
            print_table_of_game(row, coloum, table);

        }
        score_w_l = calculate_score(row, coloum, table);
        information_win_lose(score_w_l);


    }


    return 0;
}

/////////////////////////////////////////////////////////////////////////


//kullanicidan satir ve sutun sayisini belirleyecek degerleri alir
//4x4 formatinda alir
void decide_row_coloum(int *row, int *coloum, char table[21][22],
        char number_1[20], char number_2[20]) {
    int i;
    char size[8];
    char row_u[3], col_u[3]; //user'dan alinan row,col
    do {
        cout << "Oynamak istediginiz tablo boyutunu girin ~~4x4 seklinde~~" << endl;
        cin>>size;
        if (size[1] == 'x' || size[1] == 'X') {
            for (i = 0; i < 10; ++i) {
                if (size[0] == number_1[i] && size[2] == number_1[i]) {
                    (*row) = i + 1;
                    (*coloum) = i + 1;
                }
            }
        } else if (size[2] == 'x' || size[2] == 'X') {
            for (i = 0; i < 20; ++i)
                if (size[0] == number_1[i] && size[1] == number_2[i])
                    (*row) = i + 1;
            for (i = 0; i < 20; ++i)
                if (size[3] == number_1[i] && size[4] == number_2[i])
                    (*coloum) = i + 1;
        }
    } while ((*row) != (*coloum) || ((*row) < 4 || (*row) > 20) &&
            ((*coloum) < 4 || (*coloum) > 20) ||
            ((*row) % 2 != 0 || (*coloum) % 2 != 0));
}

//baslangic tablosu
//kullanicinin ya da bilgisayarin baslamasina gore degisir

void start_table(int row, int coloum, char table[21][22], char letters[20],
        char number_1[20], char number_2[20], int turn) {
    int i, j;
    for (i = 0; i <= row; ++i) {
        for (j = 0; j <= coloum + 1; ++j) {
            if ((i == 0 && j == 0) || (i == 0 && j == 1)) {
                table[i][j] = ' ';
            } else if (i == 0 && j > 1)
                table[i][j] = letters[j - 2];
            else if ((j == 0 || j == 1) && (i > 0)) {
                if (j == 0)
                    table[i][j] = number_1[i - 1];
                if (j == 1)
                    table[i][j] = number_2[i - 1];
            }
            if (i == row / 2 && j == (coloum / 2 + 1) && turn == 0) {
                table[i][j] = 'X';
                table[i][j + 1] = 'O';
                table[i + 1][j] = 'O';
                table[i + 1][j + 1] = 'X';
            }
            if (i == row / 2 && j == (coloum / 2 + 1) && turn == 1) {
                table[i][j] = 'O';
                table[i][j + 1] = 'X';
                table[i + 1][j] = 'X';
                table[i + 1][j + 1] = 'O';
            }
        }
    }
}
//tabloyu ekrana bastirir

void print_table_of_game(int row, int coloum, char table[21][22]) {
    int i, j;
    for (i = 0; i <= row; ++i) {
        for (j = 0; j <= coloum + 1; ++j) {
            cout << table[i][j];
        }
        cout << "\n";
    }
}
//kullanici yani ekran karsisindaki oyuncunun hamle koordinatlarini alir

player decide_location(int row, int coloum, char table[21][22], player player_,
        char letters[20], char number_1[20], char number_2[20]) {
    int i, j, k;
    int again_c;
    int again_r;
    char loc_r_c[5];
    char loc_r[3], loc_c[3];

    do {

        cout << "oynamak istediginiz hucreyi girin(8A gibi)" << endl;

        cin>>loc_r_c;
        loc_r[0] = loc_r_c[0];
        j = 0;

        if (isupper(loc_r_c[1])) loc_r_c[1] = tolower(loc_r_c[1]);
        else if (isupper(loc_r_c[2])) loc_r_c[2] = tolower(loc_r_c[2]);

        for (i = 0; i <= (coloum + 1); ++i) {
            if (loc_r_c[1] == letters[i]) {
                loc_c[0] = loc_r_c[1];
                loc_c[1] = '\0';
                loc_r[1] = '\0';
            } else if (loc_r_c[1] == number_2[j] && j <= row) {
                loc_r[1] = loc_r_c[1];
                loc_r[2] = '\0';
                loc_c[0] = loc_r_c[2];
                loc_c[1] = '\0';
            }
            ++j;
        }
        again_r = 0;
        // bu if mesela 4x4 tabloda 8 sutununu girersem
        if (loc_r[1] == '\0') {//1 2 3 4 5 6 7 8 9
            loc_r[1] = ' ';
            loc_r[2] = '\0';
        }

        for (i = 1; i <= row; ++i) {
            if (table[i][0] != loc_r[0] || table[i][1] != loc_r[1]) {
                ++again_r;
            }
        }
        again_c = 0; //eger dogru sey girilmezse
        //kontrol icin
        for (i = 0; i <= (coloum + 1); ++i) {
            if (table[0][i] != loc_c[0] && i > 1)
                again_c++; //olmayan bir sey girdiyse
        }
        if (loc_c[1] != '\0')//tek karakter girilmezse
            again_c = coloum;
    } while (again_r >= row || again_c >= (coloum));

    //alinan komutlari integera cevirme
    for (i = 0; i <= (coloum + 1); ++i)
        if (loc_c[0] == letters[i])
            player_.int_col = i + 2; //tabloda 0 0 bos

    for (i = 0; i <= row; ++i) {
        if (loc_r[0] == number_1[i] && loc_r[1] == number_2[i])
            player_.int_row = i + 1;
    }
    return player_;
}
//alinan konumun bos olup olmadigina bakar
//bossa 1 doluysa 0 dondurur

bool empty_full(int row, int coloum, char table[21][22], player player_) {
    bool emp_full;
    if (table[player_.int_row][player_.int_col] == '.' &&
            player_.int_row <= row && player_.int_row >= 1 &&
            player_.int_col <= (coloum + 1) && player_.int_col >= 2)//bos oldugunu gosterir
        emp_full = 1; //bos
    else
        emp_full = 0; //dolu
    return emp_full;
}

//isaret koyulacak noktanin etrafindaki karsi takimin sembollerinin sayisini bulup donduruyor
//mesela O koyulacak noktayi input parametre olarak aliyor
//sonra etrafinda OXO olabilecek yerlere bakip uzakliklarini buluyor
//ve bu uzakliklari donduruyor

avail_loc available(int row, int coloum, char table[21][22], player player_, char P1, char P2) {
    //oyuncu icin P1 O P2 X
    //bilgisayar icin P1 X P2 O

    avail_loc avail;
    int length = 0;
    int i, j;
    bool e_f; //bos mu dolu mu anlamak icin
    avail.length0 = -1;
    avail.sign_0 = -1;
    avail.length1 = 0;
    avail.sign_1 = -1;
    avail.length2 = 0;
    avail.sign_2 = -1;
    avail.length3 = 0;
    avail.sign_3 = -1;
    avail.length4 = 0;
    avail.sign_4 = -1;
    avail.length5 = 0;
    avail.sign_5 = -1;
    avail.length6 = 0;
    avail.sign_6 = -1;
    avail.length7 = 0;
    avail.sign_7 = -1;
    avail.length8 = 0;
    avail.sign_8 = -1;

    e_f = empty_full(row, coloum, table, player_);
    if (e_f == 1) {//bos
        //konulan noktanin saginda diger isaret varsa
        if (table[player_.int_row][player_.int_col + 1] == P2) {//sagda
            length = 0;
            for (i = player_.int_col + 1; i <= (coloum + 1); ++i) {
                if (table[player_.int_row][i] == P2 && i < (coloum + 1))
                    ++length;
                else if (table[player_.int_row][i] == P1)
                    i = coloum + 2;
                else if (table[player_.int_row][i] == '.')
                    length = 0;
                else if (i == coloum + 1 && table[player_.int_row][i] == P2)
                    length = 0;
            }
            avail.length1 = length;
            if (avail.length1 > 0)
                avail.sign_1 = 1;
        }
        //konulan noktanin soluna bakiyor
        if (table[player_.int_row][player_.int_col - 1] == P2) {//solda
            length = 0;
            for (i = player_.int_col - 1; i >= 2; --i) {
                if (table[player_.int_row][i] == P2 && i > 2)
                    ++length;
                else if (table[player_.int_row][i] == P1)
                    i = 1;
                else if (table[player_.int_row][i] == '.')
                    length = 0;
                else if (i == 2 && table[player_.int_row][i] == P2)
                    length = 0;
            }
            avail.length2 = length;
            if (avail.length2 > 0)
                avail.sign_2 = 2;
        }
        //konulan noktanin altina
        if (table[player_.int_row + 1][player_.int_col] == P2) {//altta
            length = 0;
            for (i = player_.int_row + 1; i <= row; ++i) {
                if (table[i][player_.int_col] == P2 && i < row)
                    ++length;
                else if (table[i][player_.int_col] == P1)
                    i = row + 1;
                else if (table[i][player_.int_col] == '.')
                    length = 0;
                else if (i == row && table[i][player_.int_col] == P2)
                    length = 0;
            }
            avail.length3 = length;
            if (avail.length3 > 0)
                avail.sign_3 = 3;
        }
        //konulan noktanin ustune
        if (table[player_.int_row - 1][player_.int_col] == P2) {//ustte
            length = 0;
            for (i = player_.int_row - 1; i >= 1; --i) {
                if (table[i][player_.int_col] == P2 && i > 1)
                    ++length;
                else if (table[i][player_.int_col] == P1)
                    i = 0;
                else if (table[i][player_.int_col] == '.')
                    length = 0;
                else if (i == 1 && table[i][player_.int_col] == P2)
                    length = 0;
            }
            avail.length4 = length;
            if (avail.length4 > 0)
                avail.sign_4 = 4;
        }
        //sol uste
        if (table[player_.int_row - 1][player_.int_col - 1] == P2) {//sol ustte
            length = 0;
            j = player_.int_col - 1;
            for (i = player_.int_row - 1; (i >= 1 && j >= 2); --i) {
                if (table[i][j] == P2 && i > 1 && j > 2)
                    ++length;
                else if (table[i][j] == P1)
                    i = -1;
                else if (table[i][j] == '.')
                    length = 0;
                else if ((i == 1 || j == 2) && table[i][j] == P2)
                    length = 0;
                --j;
            }
            avail.length5 = length;
            if (avail.length5 > 0)
                avail.sign_5 = 5; //sola
        }
        //sol alta konuldugunda sag uste dogru bakiyor
        if (table[player_.int_row + 1][player_.int_col - 1] == P2) {//sag ustte
            length = 0;
            j = player_.int_col - 1;
            for (i = player_.int_row + 1; (i <= row && j >= 2); ++i) {
                if (table[i][j] == P2 && i < row && j > 2)
                    ++length;
                else if (table[i][j] == P1)
                    i = row + 1;
                else if (table[i][j] == '.')
                    length = 0;
                else if ((i == row || j == 2) && table[i][j] == P2)
                    length = 0;
                --j;
            }
            avail.length6 = length;
            if (avail.length6 > 0)
                avail.sign_6 = 6;
        }
        //sag uste konuldugunda sol alta dogru bakiyor 
        if (table[player_.int_row - 1][player_.int_col + 1] == P2) {//sol altta
            length = 0;
            j = player_.int_col + 1;
            for (i = player_.int_row - 1; i >= 1 && j <= (coloum + 1); --i) {
                if (table[i][j] == P2 && i > 1 && j < (coloum + 1))
                    ++length;
                else if (table[i][j] == P1)
                    i = -1;
                else if (table[i][j] == '.')
                    length = 0;
                else if ((i == 1 || j == (coloum + 1)) && table[i][j] == P2)
                    length = 0;
                ++j;
            }
            avail.length7 = length;
            if (avail.length7 > 0)
                avail.sign_7 = 7;
        }

        if (table[player_.int_row + 1][player_.int_col + 1] == P2) {//sag altta
            length = 0;
            j = player_.int_col + 1;
            for (i = player_.int_row + 1; i <= row && j <= (coloum + 1); ++i) {
                if (table[i][j] == P2 && i < row && j < (coloum + 1))
                    ++length;
                else if (table[i][j] == P1)
                    i = 1000;
                else if (table[i][j] == '.')
                    length = 0;
                else if ((i == row || j == (coloum + 1)) && table[i][j] == P2)
                    length = 0;
                ++j;
            }
            avail.length8 = length;
            if (avail.length8 > 0)
                avail.sign_8 = 8;
        }

    } else if (e_f == 0) {// bos olmayan bir hucre olursa.
        avail.length0 = 0;
        avail.sign_0 = 0;
    }
    return avail;
}


//available fonksiyonuyla birlikte calisir

player control_table(int row, int coloum, char table[21][22], player player_, char P1, char P2) {
    int i, j, k;
    int length = 0;
    if ((player_.avl_location).sign_1 == 1) {//saga dogru koyuyor
        for (i = player_.int_col + 1; (i <= player_.int_col + (player_.avl_location).length1) && (i < (coloum + 1)); ++i) {
            if (table[player_.int_row][i] == P2)
                table[player_.int_row][i] = P1;
            else if (table[player_.int_row][i] != P2)
                i = 1000;
        }
    }
    if ((player_.avl_location).sign_2 == 2) {//sola dogru koyuyor
        for (i = player_.int_col - 1; (i >= player_.int_col - (player_.avl_location).length2) && (i > 2); --i) {
            if (table[player_.int_row][i] == P2)
                table[player_.int_row][i] = P1;
            else if (table[player_.int_row][i] != P2)
                i = -1;
        }
    }
    if ((player_.avl_location).sign_3 == 3) {//alta dogru koyuyor
        for (i = player_.int_row + 1; (i <= player_.int_row + (player_.avl_location).length3) && (i < row); ++i) {
            if (table[i][player_.int_col] == P2)
                table[i][player_.int_col] = P1;
            else if (table[i][player_.int_col] != P2)
                i = 1000;
        }
    }
    if ((player_.avl_location).sign_4 == 4) {// uste dogru koyuyor
        for (i = player_.int_row - 1; (i >= player_.int_row - (player_.avl_location).length4) && (i > 1); --i) {
            if (table[i][player_.int_col] == P2)
                table[i][player_.int_col] = P1;
            else if (table[i][player_.int_col] != P2)
                i = -1;
        }
    }
    if ((player_.avl_location).sign_5 == 5) {//sol uste dogru koyuyor
        j = player_.int_col - 1;
        for (i = player_.int_row - 1; (i >= player_.int_row - (player_.avl_location).length5) && (i > 1) && (j > 2); --i) {
            if (table[i][j] == P2)
                table[i][j] = P1;
            else if (table[i][j] != P2)
                i = -1;
            --j;
        }
    }
    if ((player_.avl_location).sign_6 == 6) {//sol alta dogru koyuyor
        j = player_.int_col - 1;
        for (i = player_.int_row + 1; (i <= player_.int_row + (player_.avl_location).length6) && (i < row) && (j > 2); ++i) {
            if (table[i][j] == P2)
                table[i][j] = P1;
            else if (table[i][j] != P2)
                i = 1000;
            --j;
        }
    }
    if ((player_.avl_location).sign_7 == 7) {//sol uste dogru koyuyor
        j = player_.int_col + 1;
        for (i = player_.int_row - 1; (i >= player_.int_row - (player_.avl_location).length7) && (i > 1) && (j < (coloum + 1)); --i) {
            if (table[i][j] == P2)
                table[i][j] = P1;
            else if (table[i][j] != P2)
                i = -1;
            ++j;
        }
    }
    if ((player_.avl_location).sign_8 == 8) {//sag alta dogru koyuyor
        j = player_.int_col + 1;
        for (i = player_.int_row + 1; (i <= player_.int_row + (player_.avl_location).length8) && (i < row) && (j < (coloum + 1)); ++i) {
            if (table[i][j] == P2)
                table[i][j] = P1;
            else if (table[i][j] != P2)
                i = -1;
            ++j;
        }
    }
    return player_;
}


//en uzun 'O'lari bulur
//ama zincir olarak degil sadece ayni satir veya ayni sutundakileri buluyor
//esit uzunluk olanlarda capraz varsa capraz olani seciyor
//capraz secme sebebi koseyi kapmanin oyun kazanma acisindan iyi bir hamle olmasi

player find_max_length(int row, int coloum, char table[21][22], player player_X, int i, int j) {
    int max_length = 0;
    int k, l;
    int length_left = 0, length_right = 0;
    int length_down = 0, length_up = 0;
    int cross1 = 0, cross2 = 0, cross3 = 0, cross4 = 0;
    //cross1 sag alt cross2 sag ust cross3 sol alt cross4 sol ust

    if (table[i][j + 1] == 'O') {//right
        for (k = j; k < coloum + 1; ++k) {
            if (table[i][k] == 'O')
                ++length_right;
            else if (table[i][k] == '.')
                k = 1000;
            else if (table[i][k] == 'X')
                length_right = 0;
        }
        if (length_right >= max_length &&
                table[i][j + length_right + 1] == '.' &&
                (j + length_right + 1) <= (coloum + 1)) {
            max_length = length_right;
            player_X.int_col = j + length_right + 1;
            player_X.int_row = i;
        }
    }
    if (table[i][j - 1] == 'O') {//left
        for (k = j; k > 2; --k) {
            if (table[i][k] == 'O')
                ++length_left;
            else if (table[i][k] == '.')
                k = -1;
            else if (table[i][k] == 'X')
                length_left = 0;
        }
        if (length_left >= max_length &&
                table[i][j - length_left - 1] == '.' &&
                (j - length_left - 1) >= 2) {
            max_length = length_left;
            player_X.int_col = j - length_left - 1;
            player_X.int_row = i;
        }
    }
    if (table[i + 1][j] == 'O') {//down
        for (k = i; k < row; ++k) {
            if (table[k][j] == 'O')
                ++length_down;
            else if (table[k][j] == '.')
                k = 1000;
            else if (table[k][j] == 'X')
                length_down = 0;
        }
        if (length_down >= max_length &&
                table[i + length_down + 1][j] == '.' &&
                i + length_down + 1 <= row) {
            max_length = length_down;
            player_X.int_col = j;
            player_X.int_row = i + length_down + 1;
        }
    }
    if (table[i - 1][j] == 'O') {//up
        for (k = i; k > 1; --k) {
            if (table[k][j] == 'O')
                ++length_up;
            else if (table[k][j] == '.')
                k = -1;
            else if (table[k][j] == 'X')
                length_up = 0;
        }
        if (length_up >= max_length &&
                table[i - length_up - 1][j] == '.' &&
                (i - length_up - 1) >= 1) {
            max_length = length_up;
            player_X.int_col = j;
            player_X.int_row = i - length_up - 1;
        }
    }
    if (table[i + 1][j + 1] == 'O') {//sag alt
        l = j;
        for (k = i; k < row; ++k) {
            if (table[k][l] == 'O')
                ++cross1;
            else if (table[k][l] == '.')
                k = 1000;
            else if (table[k][l] == 'X')
                cross1 = 0;
            ++l;
        }
        if (cross1 >= max_length &&
                table[i + cross1 + 1][j + cross1 + 1] == '.' &&
                j + cross1 + 1 <= coloum + 1 &&
                i + cross1 + 1 <= row) {
            max_length = cross1;
            player_X.int_col = j + cross1 + 1;
            player_X.int_row = i + cross1 + 1;
        }
    }
    if (table[i - 1][j + 1] == 'O') {//sag ust
        l = j;
        for (k = i; k > 1; --k) {
            if (table[k][l] == 'O')
                ++cross2;
            else if (table[k][l] == '.')
                k = -1;
            else if (table[k][l] == 'X')
                cross2 = 0;

            ++l;
        }
        if (cross2 >= max_length &&
                table[i - cross2 - 1][j + cross2 + 1] == '.' &&
                j + cross2 + 1 <= coloum + 1 &&
                i - cross2 - 1 >= 1) {
            max_length = cross2;
            player_X.int_col = j + cross2 + 1;
            player_X.int_row = i - cross2 - 1;
        }
    }
    if (table[i + 1][j - 1] == 'O') {//sol alt
        l = j;
        for (k = i; k < row; ++k) {
            if (table[k][l] == 'O')
                ++cross3;
            else if (table[k][l] == '.')
                k = 1000;
            else if (table[k][l] == 'X')
                cross3 = 0;
            --l;
        }
        if (cross3 >= max_length &&
                table[i + cross3 + 1][j - cross3 - 1] == '.' &&
                j - cross3 - 1 >= 2 &&
                i + cross3 + 1 <= row) {
            max_length = cross3;
            player_X.int_col = j - cross3 - 1;
            player_X.int_row = i + cross3 + 1;
        }
    }
    if (table[i - 1][j - 1] == 'O') {//sol ust
        l = j;
        for (k = i; k > 1; --k) {
            if (table[k][l] == 'O')
                ++cross4;
            else if (table[k][l] == '.')
                k = -1;
            else if (table[k][l] == 'X')
                cross4 = 0;
            --l;
        }
        if (cross4 >= max_length &&
                table[i - cross4 - 1][j - cross4 - 1] == '.' &&
                j - cross4 - 1 >= 2 &&
                i - cross4 - 1 >= 1) {
            max_length = cross4;
            player_X.int_col = j - cross4 - 1;
            player_X.int_row = i - cross4 - 1;
        }
    }

    return player_X;
}

player logical_decision(int row, int coloum, char table[21][22], player player_X) {
    int i, j;
    for (i = 1; i <= row; ++i) {
        for (j = 2; j <= coloum + 1; ++j) {
            if (table[i][j] == 'X') {
                player_X = find_max_length(row, coloum, table, player_X, i, j);
            }
        }
    }
    return player_X;
}
//tablodaki X,O sayilarini bulur
//bosluk kalmadiginda oyunu bitirmek icin win_or_lose degiskenini 1 yapar

score_win_lose calculate_score(int row, int coloum, char table[21][22]) {
    int i, j;
    int number_of_point = 0;
    score_win_lose cal_score_w_l;
    cal_score_w_l.win_or_lose = 0;
    (cal_score_w_l.player_score) = 0;
    (cal_score_w_l.computer_score) = 0;
    for (i = 0; i <= row; ++i) {
        for (j = 0; j <= coloum + 1; ++j) {
            if (table[i][j] == 'X')
                (cal_score_w_l.computer_score)++;
            else if (table[i][j] == 'O')
                (cal_score_w_l.player_score)++;
            else if (table[i][j] == '.') {//bosluk hesabi
                ++number_of_point;

            }
        }
    }
    if (number_of_point == 0)
        cal_score_w_l.win_or_lose = 1;

    return cal_score_w_l;
}
//hamle sayilarini ekrana basar
//kazanan ya da kaybeden tarafi kullaniciya bildirir

void information_win_lose(score_win_lose score_w_l) {
    cout << "oyuncu=" << score_w_l.player_score << endl;
    cout << "bilgisayar=" << score_w_l.computer_score << endl;

    if (score_w_l.win_or_lose == 1 && score_w_l.player_score > score_w_l.computer_score)
        cout << "~~~~Kazanan taraf oyuncu~~~~" << endl;
    else if (score_w_l.win_or_lose == 1 && score_w_l.computer_score > score_w_l.player_score)
        cout << "~~~~~Kazanan taraf bilgisayar~~~~" << endl;
    else if (score_w_l.win_or_lose == 1 && score_w_l.computer_score == score_w_l.player_score)
        cout << "Kazanan yok. Berabere bitti.!!!!";

}
//computer'in oyun kodlarini,fonksiyonlarini icerir

player play_comp(int row, int coloum, char table[21][22], player player_X) {
    player_X = logical_decision(row, coloum, table, player_X);
    player_X.avl_location = available(row, coloum, table, player_X, 'X', 'O');
    if (player_X.avl_location.length1 > 0 || player_X.avl_location.length2 > 0 ||
            player_X.avl_location.length3 > 0 || player_X.avl_location.length4 > 0 ||
            player_X.avl_location.length5 > 0 || player_X.avl_location.length6 > 0 ||
            player_X.avl_location.length7 > 0 || player_X.avl_location.length8 > 0)
        table[player_X.int_row][player_X.int_col] = 'X';
    //cout << "row=" << player_X.int_row << "~~~coloum=" << player_X.int_col << endl;
    player_X = control_table(row, coloum, table, player_X, 'X', 'O');
    return player_X;
}

//player'in oyun kodlarini,fonksiyonlarini icerir
//recursive

player play_player(int row, int coloum, char table[21][22], player player_O,
        char letters[20], char number_1[20], char number_2[20]) {

    // bool decide; //uygun olup olmadigina karar vermek icin
    player result;

    (player_O.avl_location) = available(row, coloum, table, player_O, 'O', 'X');

    //player_O.turn = find_whose_turn(avail_decide_O, 'O');

    if ((player_O.avl_location).length1 > 0 || (player_O.avl_location).length2 > 0 || (player_O.avl_location).length3 > 0 ||
            (player_O.avl_location).length4 > 0 || (player_O.avl_location).length5 > 0 || (player_O.avl_location).length6 > 0 ||
            (player_O.avl_location).length7 > 0 || (player_O.avl_location).length8 > 0) {
        table[player_O.int_row][player_O.int_col] = 'O';
        player_O = control_table(row, coloum, table, player_O, 'O', 'X');
        result = player_O;
    } else {//recursive. uygun olmayan hucre varsa
        cout << "Burasi uygun degil!! Tekrar belirleyin" << endl;
        player_O = decide_location(row, coloum, table, player_O, letters,
                number_1, number_2);
        player_O = play_player(row, coloum, table, player_O, letters,
                number_1, number_2);
        result = player_O;
    }
    return result;
}

/*bool find_whose_turn(player player_, char P1, bool turn) {
    bool turn_result;


    if (player_.avl_location.sign_1 != 1 && player_.avl_location.sign_2 != 2 &&
            player_.avl_location.sign_3 != 3 && player_.avl_location.sign_4 != 4 &&
            player_.avl_location.sign_5 != 5 && player_.avl_location.sign_6 != 6 &&
            player_.avl_location.sign_7 != 7 && player_.avl_location.sign_8 != 8) {

        if (P1 == 'X')
            turn_result = 1; //Oya gecer
        else if (P1 == 'O')
            turn_result = 0; //Xe gecer

        cout << P1 << "-->hamle kalmadi" << endl;

    } else {

        turn_result = turn;

    }
    return turn_result;

}*/

